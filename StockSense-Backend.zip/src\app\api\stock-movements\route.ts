import { NextRequest, NextResponse } from 'next/server';
import { getUserFromRequest } from '@/lib/auth';
import { StockService } from '@/services/StockService';

export async function POST(request: NextRequest) {
  try {
    const user = getUserFromRequest(request);
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await request.json();
    const { productId, fromLocationId, toLocationId, quantity, type, documentId } = body;

    const movement = await StockService.createMovement({
      productId,
      fromLocationId,
      toLocationId,
      quantity,
      type,
      documentId,
      createdById: user.userId
    });

    return NextResponse.json(movement, { status: 201 });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to create stock movement' }, { status: 400 });
  }
}
