import json
from datetime import datetime, timezone
from typing import Optional
from fastapi import HTTPException, status
from sqlalchemy import func
from sqlalchemy.orm import Session

from ..models import (
    MovementType, OperationStatus,
    StockLedger, Product, Location,
    Receipt, ReceiptItem,
    DeliveryOrder, DeliveryItem,
    InternalTransfer, TransferItem,
    StockAdjustment, AdjustmentItem,
    ReturnOrder, ReturnItem,
    AuditLog
)
from ..schemas import (
    ReceiptCreate, ReceiptUpdate,
    DeliveryCreate, DeliveryUpdate,
    TransferCreate, TransferUpdate,
    AdjustmentCreate, AdjustmentUpdate,
    ReturnCreate
)

def _utcnow():
    return datetime.now(timezone.utc)

def _next_ref(db: Session, prefix: str, model) -> str:
    last = db.query(func.max(model.id)).scalar() or 0
    return f"{prefix}-{last + 1:05d}"

def log_audit(db: Session, user_id: int, action: str, resource: str, resource_id: int, prev_value=None, new_value=None):
    audit = AuditLog(
        user_id=user_id,
        action=action,
        resource=resource,
        resource_id=resource_id,
        prev_value=json.dumps(prev_value) if prev_value else None,
        new_value=json.dumps(new_value) if new_value else None,
    )
    db.add(audit)

def get_stock(db: Session, product_id: int, location_id: Optional[int] = None) -> float:
    q = db.query(func.coalesce(func.sum(StockLedger.quantity), 0.0)).filter(
        StockLedger.product_id == product_id,
    )
    if location_id is not None:
        q = q.filter(StockLedger.location_id == location_id)
    return float(q.scalar())

def get_stock_by_location(db: Session, product_id: int) -> dict[int, float]:
    rows = db.query(StockLedger.location_id, func.sum(StockLedger.quantity)).filter(StockLedger.product_id == product_id).group_by(StockLedger.location_id).all()
    return {loc: float(qty) for loc, qty in rows}

def get_all_stock(db: Session) -> list[dict]:
    rows = db.query(StockLedger.product_id, StockLedger.location_id, func.sum(StockLedger.quantity).label("total")).group_by(StockLedger.product_id, StockLedger.location_id).all()
    return [{"product_id": r.product_id, "location_id": r.location_id, "total_quantity": float(r.total)} for r in rows]

def validate_stock_available(db: Session, product_id: int, location_id: int, needed: float):
    available = get_stock(db, product_id, location_id)
    if available < needed:
        raise HTTPException(status_code=400, detail=f"Insufficient stock for product {product_id} at location {location_id}: available={available}, requested={needed}")
    return available

def get_movement_history(
    db: Session, *, product_id: Optional[int] = None, location_id: Optional[int] = None,
    movement_type: Optional[MovementType] = None, reference_type: Optional[str] = None,
    from_date: Optional[datetime] = None, to_date: Optional[datetime] = None,
    limit: int = 100, offset: int = 0,
) -> list[StockLedger]:
    q = db.query(StockLedger)
    if product_id is not None: q = q.filter(StockLedger.product_id == product_id)
    if location_id is not None: q = q.filter(StockLedger.location_id == location_id)
    if movement_type is not None: q = q.filter(StockLedger.movement_type == movement_type)
    if reference_type is not None: q = q.filter(StockLedger.reference_type == reference_type)
    if from_date is not None: q = q.filter(StockLedger.created_at >= from_date)
    if to_date is not None: q = q.filter(StockLedger.created_at <= to_date)
    return q.order_by(StockLedger.created_at.desc()).offset(offset).limit(limit).all()

# RECEIPTS
def create_receipt(db: Session, data: ReceiptCreate, user_id: Optional[int] = None) -> Receipt:
    ref = _next_ref(db, "REC", Receipt)
    r = Receipt(reference=ref, vendor_name=data.vendor_name, supplier_id=data.supplier_id, scheduled_date=data.scheduled_date, notes=data.notes, created_by=user_id)
    for item in data.items: r.items.append(ReceiptItem(**item.model_dump()))
    db.add(r); db.commit(); db.refresh(r)
    return r

def get_receipt(db: Session, receipt_id: int) -> Receipt:
    r = db.query(Receipt).filter(Receipt.id == receipt_id).first()
    if not r: raise HTTPException(404, "Receipt not found")
    return r

def list_receipts(db: Session, *, status_filter=None, limit=50, offset=0) -> list[Receipt]:
    q = db.query(Receipt)
    if status_filter: q = q.filter(Receipt.status == status_filter)
    return q.order_by(Receipt.created_at.desc()).offset(offset).limit(limit).all()

def update_receipt(db: Session, receipt_id: int, data: ReceiptUpdate) -> Receipt:
    r = get_receipt(db, receipt_id)
    if r.status != OperationStatus.DRAFT: raise HTTPException(400, "Can only update receipts in DRAFT status")
    for field, value in data.model_dump(exclude_unset=True).items(): setattr(r, field, value)
    db.commit(); db.refresh(r)
    return r

def confirm_receipt(db: Session, receipt_id: int) -> Receipt:
    r = get_receipt(db, receipt_id)
    if r.status != OperationStatus.DRAFT: raise HTTPException(400, "Must be DRAFT")
    r.status = OperationStatus.CONFIRMED
    db.commit(); db.refresh(r)
    return r

def process_receipt(db: Session, receipt_id: int, user_id: Optional[int] = None) -> Receipt:
    with db.begin_nested():
        receipt = db.query(Receipt).with_for_update().filter(Receipt.id == receipt_id).first()
        if not receipt: raise HTTPException(404, "Receipt not found")
        if receipt.status in (OperationStatus.RECEIVED, OperationStatus.DONE):
            raise HTTPException(400, "Receipt already processed (Idempotency protection)")
        now = _utcnow()
        for item in receipt.items:
            if item.quantity_received == 0: item.quantity_received = item.quantity_expected
            qty_before = get_stock(db, item.product_id, item.location_id)
            db.add(StockLedger(
                product_id=item.product_id, location_id=item.location_id, movement_type=MovementType.RECEIPT, 
                quantity_before=qty_before, quantity=item.quantity_received, quantity_after=qty_before + item.quantity_received,
                reference_type="receipt", reference_id=receipt.id, batch_number=item.batch_number, expiry_date=item.expiry_date,
                created_by=user_id, created_at=now
            ))
        receipt.status = OperationStatus.DONE
        receipt.done_date = now
        log_audit(db, user_id, "PROCESS", "Receipt", receipt.id)
    db.commit(); db.refresh(receipt)
    return receipt

def cancel_receipt(db: Session, receipt_id: int) -> Receipt:
    r = get_receipt(db, receipt_id)
    if r.status == OperationStatus.DONE: raise HTTPException(400, "Cannot cancel DONE")
    if r.status == OperationStatus.CANCELLED: raise HTTPException(400, "Already cancelled")
    r.status = OperationStatus.CANCELLED
    db.commit(); db.refresh(r)
    return r

# DELIVERIES
def create_delivery(db: Session, data: DeliveryCreate, user_id: Optional[int] = None) -> DeliveryOrder:
    ref = _next_ref(db, "DEL", DeliveryOrder)
    d = DeliveryOrder(reference=ref, **data.model_dump(exclude={'items'}), created_by=user_id)
    for item in data.items: d.items.append(DeliveryItem(**item.model_dump()))
    db.add(d); db.commit(); db.refresh(d)
    return d

def get_delivery(db: Session, delivery_id: int) -> DeliveryOrder:
    d = db.query(DeliveryOrder).filter(DeliveryOrder.id == delivery_id).first()
    if not d: raise HTTPException(404, "Not found")
    return d

def list_deliveries(db: Session, *, status_filter=None, limit=50, offset=0) -> list[DeliveryOrder]:
    q = db.query(DeliveryOrder)
    if status_filter: q = q.filter(DeliveryOrder.status == status_filter)
    return q.order_by(DeliveryOrder.created_at.desc()).offset(offset).limit(limit).all()

def update_delivery(db: Session, delivery_id: int, data: DeliveryUpdate) -> DeliveryOrder:
    d = get_delivery(db, delivery_id)
    if d.status != OperationStatus.DRAFT: raise HTTPException(400, "Must be DRAFT")
    for f, v in data.model_dump(exclude_unset=True).items(): setattr(d, f, v)
    db.commit(); db.refresh(d)
    return d

def confirm_delivery(db: Session, delivery_id: int) -> DeliveryOrder:
    d = get_delivery(db, delivery_id)
    if d.status != OperationStatus.DRAFT: raise HTTPException(400, "Must be DRAFT")
    d.status = OperationStatus.CONFIRMED
    db.commit(); db.refresh(d)
    return d

def process_delivery(db: Session, delivery_id: int, user_id: Optional[int] = None) -> DeliveryOrder:
    with db.begin_nested():
        d = db.query(DeliveryOrder).with_for_update().filter(DeliveryOrder.id == delivery_id).first()
        if not d: raise HTTPException(404, "Not found")
        if d.status in (OperationStatus.SHIPPED, OperationStatus.DELIVERED, OperationStatus.DONE): raise HTTPException(400, "Already processed")
        now = _utcnow()
        for item in d.items:
            qty = item.quantity_delivered if item.quantity_delivered > 0 else item.quantity_ordered
            validate_stock_available(db, item.product_id, item.location_id, qty)
        for item in d.items:
            if item.quantity_delivered == 0: item.quantity_delivered = item.quantity_ordered
            qty_before = get_stock(db, item.product_id, item.location_id)
            db.add(StockLedger(
                product_id=item.product_id, location_id=item.location_id, movement_type=MovementType.DELIVERY, 
                quantity_before=qty_before, quantity=-item.quantity_delivered, quantity_after=qty_before - item.quantity_delivered,
                reference_type="delivery", reference_id=d.id, created_by=user_id, created_at=now
            ))
        d.status = OperationStatus.DONE
        d.done_date = now
        log_audit(db, user_id, "PROCESS", "Delivery", d.id)
    db.commit(); db.refresh(d)
    return d

def cancel_delivery(db: Session, delivery_id: int) -> DeliveryOrder:
    d = get_delivery(db, delivery_id)
    if d.status == OperationStatus.DONE: raise HTTPException(400, "Cannot cancel DONE")
    if d.status == OperationStatus.CANCELLED: raise HTTPException(400, "Already cancelled")
    d.status = OperationStatus.CANCELLED
    db.commit(); db.refresh(d)
    return d

# TRANSFERS
def create_transfer(db: Session, data: TransferCreate, user_id: Optional[int] = None) -> InternalTransfer:
    ref = _next_ref(db, "TRF", InternalTransfer)
    t = InternalTransfer(reference=ref, **data.model_dump(exclude={'items'}), created_by=user_id)
    for item in data.items: t.items.append(TransferItem(**item.model_dump()))
    db.add(t); db.commit(); db.refresh(t)
    return t

def get_transfer(db: Session, transfer_id: int) -> InternalTransfer:
    t = db.query(InternalTransfer).filter(InternalTransfer.id == transfer_id).first()
    if not t: raise HTTPException(404, "Not found")
    return t

def list_transfers(db: Session, *, status_filter=None, limit=50, offset=0) -> list[InternalTransfer]:
    q = db.query(InternalTransfer)
    if status_filter: q = q.filter(InternalTransfer.status == status_filter)
    return q.order_by(InternalTransfer.created_at.desc()).offset(offset).limit(limit).all()

def update_transfer(db: Session, transfer_id: int, data: TransferUpdate) -> InternalTransfer:
    t = get_transfer(db, transfer_id)
    if t.status != OperationStatus.DRAFT: raise HTTPException(400, "Must be DRAFT")
    for f, v in data.model_dump(exclude_unset=True).items(): setattr(t, f, v)
    db.commit(); db.refresh(t)
    return t

def confirm_transfer(db: Session, transfer_id: int) -> InternalTransfer:
    t = get_transfer(db, transfer_id)
    if t.status != OperationStatus.DRAFT: raise HTTPException(400, "Must be DRAFT")
    t.status = OperationStatus.CONFIRMED
    db.commit(); db.refresh(t)
    return t

def process_transfer(db: Session, transfer_id: int, user_id: Optional[int] = None) -> InternalTransfer:
    with db.begin_nested():
        t = db.query(InternalTransfer).with_for_update().filter(InternalTransfer.id == transfer_id).first()
        if not t: raise HTTPException(404, "Not found")
        if t.status == OperationStatus.DONE: raise HTTPException(400, "Already processed")
        now = _utcnow()
        for item in t.items: validate_stock_available(db, item.product_id, t.source_location_id, item.quantity)
        for item in t.items:
            src_qty = get_stock(db, item.product_id, t.source_location_id)
            dest_qty = get_stock(db, item.product_id, t.destination_location_id)
            db.add(StockLedger(
                product_id=item.product_id, location_id=t.source_location_id, movement_type=MovementType.TRANSFER_OUT, 
                quantity_before=src_qty, quantity=-item.quantity, quantity_after=src_qty - item.quantity,
                reference_type="transfer", reference_id=t.id, created_by=user_id, created_at=now
            ))
            db.add(StockLedger(
                product_id=item.product_id, location_id=t.destination_location_id, movement_type=MovementType.TRANSFER_IN, 
                quantity_before=dest_qty, quantity=item.quantity, quantity_after=dest_qty + item.quantity,
                reference_type="transfer", reference_id=t.id, created_by=user_id, created_at=now
            ))
        t.status = OperationStatus.DONE
        t.done_date = now
        log_audit(db, user_id, "PROCESS", "Transfer", t.id)
    db.commit(); db.refresh(t)
    return t

def cancel_transfer(db: Session, transfer_id: int) -> InternalTransfer:
    t = get_transfer(db, transfer_id)
    if t.status == OperationStatus.DONE: raise HTTPException(400, "Cannot cancel DONE")
    if t.status == OperationStatus.CANCELLED: raise HTTPException(400, "Already cancelled")
    t.status = OperationStatus.CANCELLED
    db.commit(); db.refresh(t)
    return t

# ADJUSTMENTS
def create_adjustment(db: Session, data: AdjustmentCreate, user_id: Optional[int] = None) -> StockAdjustment:
    ref = _next_ref(db, "ADJ", StockAdjustment)
    a = StockAdjustment(reference=ref, location_id=data.location_id, reason=data.reason, notes=data.notes, created_by=user_id)
    for item in data.items:
        diff = item.physical_quantity - item.recorded_quantity
        a.items.append(AdjustmentItem(product_id=item.product_id, recorded_quantity=item.recorded_quantity, physical_quantity=item.physical_quantity, difference=diff))
    db.add(a); db.commit(); db.refresh(a)
    return a

def get_adjustment(db: Session, adjustment_id: int) -> StockAdjustment:
    a = db.query(StockAdjustment).filter(StockAdjustment.id == adjustment_id).first()
    if not a: raise HTTPException(404, "Not found")
    return a

def list_adjustments(db: Session, *, status_filter=None, limit=50, offset=0) -> list[StockAdjustment]:
    q = db.query(StockAdjustment)
    if status_filter: q = q.filter(StockAdjustment.status == status_filter)
    return q.order_by(StockAdjustment.created_at.desc()).offset(offset).limit(limit).all()

def update_adjustment(db: Session, adjustment_id: int, data: AdjustmentUpdate) -> StockAdjustment:
    a = get_adjustment(db, adjustment_id)
    if a.status != OperationStatus.DRAFT: raise HTTPException(400, "Must be DRAFT")
    for f, v in data.model_dump(exclude_unset=True).items(): setattr(a, f, v)
    db.commit(); db.refresh(a)
    return a

def process_adjustment(db: Session, adjustment_id: int, user_id: Optional[int] = None) -> StockAdjustment:
    with db.begin_nested():
        a = db.query(StockAdjustment).with_for_update().filter(StockAdjustment.id == adjustment_id).first()
        if not a: raise HTTPException(404, "Not found")
        if a.status == OperationStatus.DONE: raise HTTPException(400, "Already processed")
        now = _utcnow()
        for item in a.items:
            if item.difference == 0: continue
            qty_before = get_stock(db, item.product_id, a.location_id)
            if qty_before + item.difference < 0:
                raise HTTPException(400, f"Cannot adjust below zero for product {item.product_id}")
            db.add(StockLedger(
                product_id=item.product_id, location_id=a.location_id, movement_type=MovementType.ADJUSTMENT, 
                quantity_before=qty_before, quantity=item.difference, quantity_after=qty_before + item.difference,
                reference_type="adjustment", reference_id=a.id, reason=a.reason, created_by=user_id, created_at=now
            ))
        a.status = OperationStatus.DONE
        a.adjustment_date = now
        log_audit(db, user_id, "PROCESS", "Adjustment", a.id)
    db.commit(); db.refresh(a)
    return a

def cancel_adjustment(db: Session, adjustment_id: int) -> StockAdjustment:
    a = get_adjustment(db, adjustment_id)
    if a.status == OperationStatus.DONE: raise HTTPException(400, "Cannot cancel DONE")
    if a.status == OperationStatus.CANCELLED: raise HTTPException(400, "Already cancelled")
    a.status = OperationStatus.CANCELLED
    db.commit(); db.refresh(a)
    return a
