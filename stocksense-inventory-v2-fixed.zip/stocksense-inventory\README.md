# StockSense Inventory Management System (v2.0)

A polished, secure, and production-ready inventory management backend built with FastAPI and SQLAlchemy.

## 🚀 Features
* **Role-Based Access Control (RBAC):** Secure JWT authentication with Admin, Manager, Staff, and Viewer roles.
* **Complete Workflows:** Full lifecycle for Receipts, Deliveries, Internal Transfers, Adjustments, and Returns.
* **Immutable Stock Ledger:** Every transaction is recorded for full traceability and auditability.
* **Transaction Safety & Concurrency:** Robust idempotency checks, DB-level locks, and strict validation to prevent negative stock and duplicate processing.
* **Analytics Dashboard:** APIs to monitor stock levels, valuation, and daily activity.
* **Master Data Management:** Full CRUD for Products, Locations, and Suppliers.
* **Docker Ready:** Includes `Dockerfile` and `docker-compose.yml` configured for PostgreSQL.

## 📂 Architecture & Directory Structure
```text
stocksense-inventory/
├── alembic/                # Database migrations
├── app/
│   ├── auth.py             # JWT & RBAC utilities
│   ├── config.py           # Pydantic Settings & Env Vars
│   ├── database.py         # SQLAlchemy engine setup
│   ├── main.py             # FastAPI entrypoint
│   ├── models.py           # Core SQL tables
│   ├── schemas.py          # Pydantic validation models
│   ├── routers/            # API Endpoints (auth, dashboard, inventory...)
│   └── services/           # Business logic & transaction handling
├── tests/                  # Pytest suite (~35+ tests)
├── .env.example            # Example configuration
├── docker-compose.yml      # Production/Dev deployment
└── seed_data.py            # Demo data generator
```

## 🛠 Installation & Local Development

1. **Configure Environment:**
   Copy `.env.example` to `.env` and adjust the variables.

2. **Install Dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

3. **Database Migrations:**
   ```bash
   alembic revision --autogenerate -m "Initial schema"
   alembic upgrade head
   ```

4. **Seed Demo Data (Optional):**
   ```bash
   python seed_data.py
   ```
   *Creates default users: `admin`/`admin123`, `manager`/`manager123`*

5. **Run the Backend:**
   ```bash
   uvicorn app.main:app --reload
   ```

6. **View Documentation:**
   Visit `http://localhost:8000/docs` for the interactive OpenAPI UI.

## 🐳 Docker Deployment
To run the entire stack (FastAPI + PostgreSQL) via Docker Compose:
```bash
docker-compose up --build -d
```
The health check is available at `/health`.

## 🧪 Testing
We maintain a robust Pytest suite checking transaction safety, locking, and basic CRUD operations.
```bash
pytest
```

## 🛡 Security Notes
* **Never commit `.env` with actual secrets.**
* Passwords are hashed via bcrypt.
* Update `CORS_ORIGINS` in production.
* Adjust `SECRET_KEY` in your production deployment.
