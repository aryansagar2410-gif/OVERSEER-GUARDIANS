from typing import Optional
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import OperationStatus, User
from ..schemas import AdjustmentCreate, AdjustmentUpdate, AdjustmentOut
from ..services import inventory_service as svc
from ..auth import get_staff, get_manager

router = APIRouter(prefix="/adjustments", tags=["⚖️ Stock Adjustments"])

@router.post("/", response_model=AdjustmentOut, status_code=201)
def create_adjustment(data: AdjustmentCreate, db: Session = Depends(get_db), current_user: User = Depends(get_manager)):
    return svc.create_adjustment(db, data, user_id=current_user.id)

@router.get("/", response_model=list[AdjustmentOut])
def list_adjustments(
    status: Optional[OperationStatus] = Query(None),
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_staff)
):
    return svc.list_adjustments(db, status_filter=status, limit=limit, offset=offset)

@router.get("/{adjustment_id}", response_model=AdjustmentOut)
def get_adjustment(adjustment_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_staff)):
    return svc.get_adjustment(db, adjustment_id)

@router.patch("/{adjustment_id}", response_model=AdjustmentOut)
def update_adjustment(adjustment_id: int, data: AdjustmentUpdate, db: Session = Depends(get_db), current_user: User = Depends(get_manager)):
    return svc.update_adjustment(db, adjustment_id, data)

@router.post("/{adjustment_id}/validate", response_model=AdjustmentOut)
def validate_adjustment(adjustment_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_manager)):
    return svc.process_adjustment(db, adjustment_id, user_id=current_user.id)

@router.post("/{adjustment_id}/cancel", response_model=AdjustmentOut)
def cancel_adjustment(adjustment_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_manager)):
    return svc.cancel_adjustment(db, adjustment_id)
