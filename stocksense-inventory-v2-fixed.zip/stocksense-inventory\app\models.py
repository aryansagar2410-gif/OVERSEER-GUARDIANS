import enum
from datetime import datetime, timezone
from sqlalchemy import (
    Column, Integer, Float, String, Text, DateTime, Boolean,
    ForeignKey, Enum as SQLEnum, Date
)
from sqlalchemy.orm import relationship
from .database import Base

def _utcnow():
    return datetime.now(timezone.utc)

# ──────────────────────────────────────────────
# Enums
# ──────────────────────────────────────────────

class UserRole(str, enum.Enum):
    ADMIN = "ADMIN"
    MANAGER = "MANAGER"
    STAFF = "STAFF"
    VIEWER = "VIEWER"

class MovementType(str, enum.Enum):
    RECEIPT = "RECEIPT"
    DELIVERY = "DELIVERY"
    TRANSFER_IN = "TRANSFER_IN"
    TRANSFER_OUT = "TRANSFER_OUT"
    ADJUSTMENT = "ADJUSTMENT"
    RETURN = "RETURN"
    DAMAGE = "DAMAGE"
    EXPIRY = "EXPIRY"

class OperationStatus(str, enum.Enum):
    DRAFT = "DRAFT"
    CONFIRMED = "CONFIRMED"
    PARTIALLY_RECEIVED = "PARTIALLY_RECEIVED" # For receipts/PO
    RECEIVED = "RECEIVED"                     # For receipts/PO
    SHIPPED = "SHIPPED"                       # For deliveries
    DELIVERED = "DELIVERED"                   # For deliveries
    DONE = "DONE"                             # General completed state
    CANCELLED = "CANCELLED"

# ──────────────────────────────────────────────
# Core Master Data
# ──────────────────────────────────────────────

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), unique=True, index=True, nullable=False)
    username = Column(String(50), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    role = Column(SQLEnum(UserRole), default=UserRole.VIEWER, nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=_utcnow)

class Location(Base):
    __tablename__ = "locations"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    code = Column(String(50), unique=True, index=True)
    address = Column(Text, nullable=True)
    type = Column(String(50), default="WAREHOUSE") # WAREHOUSE, STORE, BRANCH
    is_active = Column(Boolean, default=True)

class Supplier(Base):
    __tablename__ = "suppliers"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(200), nullable=False, index=True)
    contact_person = Column(String(100), nullable=True)
    email = Column(String(255), nullable=True)
    phone = Column(String(50), nullable=True)
    address = Column(Text, nullable=True)
    tax_number = Column(String(50), nullable=True)
    is_active = Column(Boolean, default=True)
    notes = Column(Text, nullable=True)
    
    products = relationship("Product", back_populates="supplier")

class Product(Base):
    __tablename__ = "products"
    id = Column(Integer, primary_key=True, index=True)
    sku = Column(String(100), unique=True, index=True, nullable=False)
    barcode = Column(String(100), unique=True, index=True, nullable=True)
    name = Column(String(255), nullable=False, index=True)
    description = Column(Text, nullable=True)
    category = Column(String(100), index=True, nullable=True)
    brand = Column(String(100), nullable=True)
    uom = Column(String(50), default="pcs", nullable=False)
    cost_price = Column(Float, default=0.0)
    selling_price = Column(Float, default=0.0)
    
    # Stock Alert thresholds
    min_stock_level = Column(Float, default=0.0)
    max_stock_level = Column(Float, default=0.0)
    reorder_level = Column(Float, default=0.0)
    
    supplier_id = Column(Integer, ForeignKey("suppliers.id", ondelete="SET NULL"), nullable=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=_utcnow)
    updated_at = Column(DateTime, default=_utcnow, onupdate=_utcnow)

    supplier = relationship("Supplier", back_populates="products")

# ──────────────────────────────────────────────
# Ledger & Audit
# ──────────────────────────────────────────────

class StockLedger(Base):
    """
    Single source of truth for stock. IMMUTABLE.
    """
    __tablename__ = "stock_ledger"
    id = Column(Integer, primary_key=True, index=True)
    product_id = Column(Integer, ForeignKey("products.id"), nullable=False, index=True)
    location_id = Column(Integer, ForeignKey("locations.id"), nullable=False, index=True)
    movement_type = Column(SQLEnum(MovementType), nullable=False, index=True)
    
    quantity_before = Column(Float, nullable=False, default=0.0)
    quantity = Column(Float, nullable=False) # The change (+ or -)
    quantity_after = Column(Float, nullable=False, default=0.0)
    
    reference_type = Column(String(50), nullable=False)
    reference_id = Column(Integer, nullable=False)
    
    # Batch/Expiry management
    batch_number = Column(String(100), nullable=True)
    expiry_date = Column(Date, nullable=True)
    
    reason = Column(String(255), nullable=True)
    notes = Column(Text, nullable=True)
    created_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=_utcnow, index=True)

class AuditLog(Base):
    __tablename__ = "audit_logs"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    action = Column(String(100), nullable=False, index=True)
    resource = Column(String(100), nullable=False)
    resource_id = Column(Integer, nullable=True)
    prev_value = Column(Text, nullable=True) # Stored as JSON string
    new_value = Column(Text, nullable=True)  # Stored as JSON string
    ip_address = Column(String(50), nullable=True)
    created_at = Column(DateTime, default=_utcnow, index=True)

# ──────────────────────────────────────────────
# Transactions
# ──────────────────────────────────────────────

class Receipt(Base):
    __tablename__ = "receipts"
    id = Column(Integer, primary_key=True, index=True)
    reference = Column(String(50), unique=True, nullable=False, index=True)
    supplier_id = Column(Integer, ForeignKey("suppliers.id"), nullable=True)
    vendor_name = Column(String(200), nullable=True) # Fallback if no supplier_id
    status = Column(SQLEnum(OperationStatus), default=OperationStatus.DRAFT, nullable=False)
    scheduled_date = Column(DateTime, nullable=True)
    done_date = Column(DateTime, nullable=True)
    notes = Column(Text, nullable=True)
    created_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    approved_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=_utcnow)
    updated_at = Column(DateTime, default=_utcnow, onupdate=_utcnow)

    items = relationship("ReceiptItem", back_populates="receipt", cascade="all, delete-orphan")

class ReceiptItem(Base):
    __tablename__ = "receipt_items"
    id = Column(Integer, primary_key=True, index=True)
    receipt_id = Column(Integer, ForeignKey("receipts.id", ondelete="CASCADE"), nullable=False)
    product_id = Column(Integer, ForeignKey("products.id"), nullable=False)
    location_id = Column(Integer, ForeignKey("locations.id"), nullable=False)
    quantity_expected = Column(Float, nullable=False)
    quantity_received = Column(Float, nullable=False, default=0)
    unit_price = Column(Float, nullable=True)
    
    # Batch/Expiry
    batch_number = Column(String(100), nullable=True)
    expiry_date = Column(Date, nullable=True)

    receipt = relationship("Receipt", back_populates="items")


class DeliveryOrder(Base):
    __tablename__ = "delivery_orders"
    id = Column(Integer, primary_key=True, index=True)
    reference = Column(String(50), unique=True, nullable=False, index=True)
    customer_name = Column(String(200), nullable=False)
    status = Column(SQLEnum(OperationStatus), default=OperationStatus.DRAFT, nullable=False)
    scheduled_date = Column(DateTime, nullable=True)
    done_date = Column(DateTime, nullable=True)
    notes = Column(Text, nullable=True)
    created_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=_utcnow)
    updated_at = Column(DateTime, default=_utcnow, onupdate=_utcnow)

    items = relationship("DeliveryItem", back_populates="delivery", cascade="all, delete-orphan")

class DeliveryItem(Base):
    __tablename__ = "delivery_items"
    id = Column(Integer, primary_key=True, index=True)
    delivery_id = Column(Integer, ForeignKey("delivery_orders.id", ondelete="CASCADE"), nullable=False)
    product_id = Column(Integer, ForeignKey("products.id"), nullable=False)
    location_id = Column(Integer, ForeignKey("locations.id"), nullable=False)
    quantity_ordered = Column(Float, nullable=False)
    quantity_delivered = Column(Float, nullable=False, default=0)

    delivery = relationship("DeliveryOrder", back_populates="items")


class InternalTransfer(Base):
    __tablename__ = "internal_transfers"
    id = Column(Integer, primary_key=True, index=True)
    reference = Column(String(50), unique=True, nullable=False, index=True)
    source_location_id = Column(Integer, ForeignKey("locations.id"), nullable=False)
    destination_location_id = Column(Integer, ForeignKey("locations.id"), nullable=False)
    status = Column(SQLEnum(OperationStatus), default=OperationStatus.DRAFT, nullable=False)
    scheduled_date = Column(DateTime, nullable=True)
    done_date = Column(DateTime, nullable=True)
    notes = Column(Text, nullable=True)
    created_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=_utcnow)
    updated_at = Column(DateTime, default=_utcnow, onupdate=_utcnow)

    items = relationship("TransferItem", back_populates="transfer", cascade="all, delete-orphan")

class TransferItem(Base):
    __tablename__ = "transfer_items"
    id = Column(Integer, primary_key=True, index=True)
    transfer_id = Column(Integer, ForeignKey("internal_transfers.id", ondelete="CASCADE"), nullable=False)
    product_id = Column(Integer, ForeignKey("products.id"), nullable=False)
    quantity = Column(Float, nullable=False)

    transfer = relationship("InternalTransfer", back_populates="items")


class StockAdjustment(Base):
    __tablename__ = "stock_adjustments"
    id = Column(Integer, primary_key=True, index=True)
    reference = Column(String(50), unique=True, nullable=False, index=True)
    location_id = Column(Integer, ForeignKey("locations.id"), nullable=False)
    status = Column(SQLEnum(OperationStatus), default=OperationStatus.DRAFT, nullable=False)
    adjustment_date = Column(DateTime, nullable=True)
    reason = Column(String(100), nullable=True)
    notes = Column(Text, nullable=True)
    created_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=_utcnow)
    updated_at = Column(DateTime, default=_utcnow, onupdate=_utcnow)

    items = relationship("AdjustmentItem", back_populates="adjustment", cascade="all, delete-orphan")

class AdjustmentItem(Base):
    __tablename__ = "adjustment_items"
    id = Column(Integer, primary_key=True, index=True)
    adjustment_id = Column(Integer, ForeignKey("stock_adjustments.id", ondelete="CASCADE"), nullable=False)
    product_id = Column(Integer, ForeignKey("products.id"), nullable=False)
    recorded_quantity = Column(Float, nullable=False)
    physical_quantity = Column(Float, nullable=False)
    difference = Column(Float, nullable=False)

    adjustment = relationship("StockAdjustment", back_populates="items")


class ReturnOrder(Base):
    __tablename__ = "return_orders"
    id = Column(Integer, primary_key=True, index=True)
    reference = Column(String(50), unique=True, nullable=False, index=True)
    return_type = Column(String(50), nullable=False) # CUSTOMER, SUPPLIER
    status = Column(SQLEnum(OperationStatus), default=OperationStatus.DRAFT, nullable=False)
    customer_or_supplier_name = Column(String(200), nullable=True)
    done_date = Column(DateTime, nullable=True)
    notes = Column(Text, nullable=True)
    created_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=_utcnow)
    updated_at = Column(DateTime, default=_utcnow, onupdate=_utcnow)
    
    items = relationship("ReturnItem", back_populates="return_order", cascade="all, delete-orphan")

class ReturnItem(Base):
    __tablename__ = "return_items"
    id = Column(Integer, primary_key=True, index=True)
    return_id = Column(Integer, ForeignKey("return_orders.id", ondelete="CASCADE"), nullable=False)
    product_id = Column(Integer, ForeignKey("products.id"), nullable=False)
    location_id = Column(Integer, ForeignKey("locations.id"), nullable=False)
    quantity = Column(Float, nullable=False)
    reason = Column(String(255), nullable=True)

    return_order = relationship("ReturnOrder", back_populates="items")
