import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate, Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { LayoutDashboard, Package, ArrowRightLeft, LogOut } from 'lucide-react';

const API_URL = 'http://localhost:8000/api/v1';

// Setup Axios
axios.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Components
const Login = ({ setAuth }: { setAuth: (val: boolean) => void }) => {
  const [username, setUsername] = useState('admin');
  const [password, setPassword] = useState('admin123');
  const [error, setError] = useState('');
  
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const fd = new URLSearchParams();
      fd.append('username', username);
      fd.append('password', password);
      const res = await axios.post(`${API_URL}/auth/login`, fd);
      localStorage.setItem('token', res.data.access_token);
      setAuth(true);
    } catch (err) {
      setError('Invalid credentials');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <div className="max-w-md w-full bg-white rounded-lg shadow-md p-8">
        <h2 className="text-2xl font-bold text-center mb-6 text-blue-600">StockSense</h2>
        {error && <div className="bg-red-100 text-red-600 p-3 rounded mb-4 text-sm">{error}</div>}
        <form onSubmit={handleLogin}>
          <div className="mb-4">
            <label className="block text-sm font-medium mb-1">Username</label>
            <input className="w-full border p-2 rounded" value={username} onChange={e => setUsername(e.target.value)} />
          </div>
          <div className="mb-6">
            <label className="block text-sm font-medium mb-1">Password</label>
            <input type="password" className="w-full border p-2 rounded" value={password} onChange={e => setPassword(e.target.value)} />
          </div>
          <button className="w-full bg-blue-600 text-white p-2 rounded hover:bg-blue-700">Login</button>
        </form>
      </div>
    </div>
  );
};

const Layout = ({ children, setAuth }: { children: React.ReactNode, setAuth: (val: boolean) => void }) => {
  const navigate = useNavigate();
  const handleLogout = () => {
    localStorage.removeItem('token');
    setAuth(false);
    navigate('/');
  };

  return (
    <div className="flex h-screen bg-gray-100">
      <aside className="w-64 bg-slate-900 text-white flex flex-col">
        <div className="p-4 text-xl font-bold border-b border-slate-800">StockSense</div>
        <nav className="flex-1 p-4 space-y-2">
          <Link to="/" className="flex items-center gap-3 p-2 rounded hover:bg-slate-800"><LayoutDashboard size={20}/> Dashboard</Link>
          <Link to="/products" className="flex items-center gap-3 p-2 rounded hover:bg-slate-800"><Package size={20}/> Products</Link>
          <Link to="/inventory" className="flex items-center gap-3 p-2 rounded hover:bg-slate-800"><ArrowRightLeft size={20}/> Inventory Flow</Link>
        </nav>
        <div className="p-4 border-t border-slate-800">
          <button onClick={handleLogout} className="flex items-center gap-3 p-2 w-full text-left rounded hover:bg-slate-800 text-red-400">
            <LogOut size={20}/> Logout
          </button>
        </div>
      </aside>
      <main className="flex-1 overflow-auto p-8">
        {children}
      </main>
    </div>
  );
};

const Dashboard = () => {
  const [stats, setStats] = useState<any>(null);
  
  useEffect(() => {
    axios.get(`${API_URL}/dashboard/stats`).then(r => setStats(r.data)).catch(console.error);
  }, []);

  if (!stats) return <div>Loading...</div>;

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Dashboard Overview</h1>
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100">
          <div className="text-gray-500 text-sm font-medium">Total Products</div>
          <div className="text-3xl font-bold text-gray-800 mt-2">{stats.total_products}</div>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100">
          <div className="text-gray-500 text-sm font-medium">Total Stock Units</div>
          <div className="text-3xl font-bold text-blue-600 mt-2">{stats.total_stock_units}</div>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100 border-l-4 border-l-yellow-400">
          <div className="text-gray-500 text-sm font-medium">Low Stock Alerts</div>
          <div className="text-3xl font-bold text-yellow-600 mt-2">{stats.low_stock_products}</div>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100 border-l-4 border-l-red-500">
          <div className="text-gray-500 text-sm font-medium">Out of Stock</div>
          <div className="text-3xl font-bold text-red-600 mt-2">{stats.out_of_stock_products}</div>
        </div>
      </div>
    </div>
  );
};

const Products = () => {
  const [products, setProducts] = useState<any[]>([]);
  useEffect(() => {
    axios.get(`${API_URL}/products`).then(r => setProducts(r.data)).catch(console.error);
  }, []);

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Products</h1>
        <button className="bg-blue-600 text-white px-4 py-2 rounded shadow hover:bg-blue-700 text-sm">Add Product</button>
      </div>
      <div className="bg-white rounded-lg shadow-sm overflow-hidden border border-gray-200">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-gray-50 border-b border-gray-200 text-sm text-gray-600">
              <th className="p-4 font-medium">SKU</th>
              <th className="p-4 font-medium">Name</th>
              <th className="p-4 font-medium">Category</th>
              <th className="p-4 font-medium">Price</th>
            </tr>
          </thead>
          <tbody>
            {products.map(p => (
              <tr key={p.id} className="border-b border-gray-100 hover:bg-gray-50">
                <td className="p-4 text-sm font-mono">{p.sku}</td>
                <td className="p-4 text-sm font-medium">{p.name}</td>
                <td className="p-4 text-sm text-gray-500">{p.category || '-'}</td>
                <td className="p-4 text-sm text-gray-500">${p.selling_price}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

const App = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(!!localStorage.getItem('token'));

  if (!isAuthenticated) {
    return <Login setAuth={setIsAuthenticated} />;
  }

  return (
    <BrowserRouter>
      <Layout setAuth={setIsAuthenticated}>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/products" element={<Products />} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </Layout>
    </BrowserRouter>
  );
};

export default App;
