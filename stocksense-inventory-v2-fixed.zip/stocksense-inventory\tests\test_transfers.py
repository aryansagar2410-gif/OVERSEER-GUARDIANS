"""
Tests for Internal Transfers — move stock between locations, total unchanged.

Key scenario from hackathon spec:
    Warehouse A: 100, Warehouse B: 50
    Transfer 20 from A → B
    A: 80, B: 70, TOTAL = 150
"""
from tests.conftest import seed_stock


class TestTransferCRUD:

    def test_create_transfer(self, client):
        resp = client.post("/api/v1/transfers/", json={
            "source_location_id": 1,
            "destination_location_id": 2,
            "items": [{"product_id": 1, "quantity": 20}],
        })
        assert resp.status_code == 201
        data = resp.json()
        assert data["status"] == "DRAFT"
        assert data["reference"].startswith("TRF-")
        assert data["source_location_id"] == 1
        assert data["destination_location_id"] == 2

    def test_reject_same_location_transfer(self, client):
        """Source and destination must be different."""
        resp = client.post("/api/v1/transfers/", json={
            "source_location_id": 1,
            "destination_location_id": 1,  # same!
            "items": [{"product_id": 1, "quantity": 10}],
        })
        assert resp.status_code == 422  # validation error


class TestTransferLifecycle:

    def test_transfer_preserves_total_stock(self, client):
        """
        THE CORE TEST:
        Warehouse A (loc 1): 100
        Warehouse B (loc 2): 50
        Transfer 20 from A → B
        A: 80, B: 70, TOTAL = 150
        """
        # Seed: 100 at location 1, 50 at location 2
        seed_stock(client, product_id=1, quantity=100, location_id=1)
        seed_stock(client, product_id=1, quantity=50, location_id=2)

        # Verify initial state
        resp_a = client.get("/api/v1/stock/1?location_id=1")
        resp_b = client.get("/api/v1/stock/1?location_id=2")
        assert resp_a.json()["total_quantity"] == 100.0
        assert resp_b.json()["total_quantity"] == 50.0

        # Transfer 20 from location 1 → location 2
        resp = client.post("/api/v1/transfers/", json={
            "source_location_id": 1,
            "destination_location_id": 2,
            "items": [{"product_id": 1, "quantity": 20}],
        })
        tid = resp.json()["id"]
        resp2 = client.post(f"/api/v1/transfers/{tid}/validate")
        assert resp2.status_code == 200
        assert resp2.json()["status"] == "DONE"

        # Verify: A=80, B=70
        resp_a = client.get("/api/v1/stock/1?location_id=1")
        resp_b = client.get("/api/v1/stock/1?location_id=2")
        assert resp_a.json()["total_quantity"] == 80.0
        assert resp_b.json()["total_quantity"] == 70.0

        # Verify: TOTAL = 150 (unchanged!)
        resp_total = client.get("/api/v1/stock/1")
        assert resp_total.json()["total_quantity"] == 150.0

    def test_transfer_by_location_breakdown(self, client):
        """The by-location endpoint shows correct breakdown after transfer."""
        seed_stock(client, product_id=1, quantity=100, location_id=1)
        seed_stock(client, product_id=1, quantity=50, location_id=2)

        resp = client.post("/api/v1/transfers/", json={
            "source_location_id": 1,
            "destination_location_id": 2,
            "items": [{"product_id": 1, "quantity": 20}],
        })
        client.post(f"/api/v1/transfers/{resp.json()['id']}/validate")

        resp = client.get("/api/v1/stock/1/by-location")
        data = resp.json()
        assert data["total"] == 150.0
        locations = {loc["location_id"]: loc["quantity"] for loc in data["locations"]}
        assert locations[1] == 80.0
        assert locations[2] == 70.0

    def test_transfer_rejects_insufficient_source_stock(self, client):
        """Cannot transfer more than available at source location."""
        seed_stock(client, product_id=1, quantity=30, location_id=1)

        resp = client.post("/api/v1/transfers/", json={
            "source_location_id": 1,
            "destination_location_id": 2,
            "items": [{"product_id": 1, "quantity": 50}],  # > 30 available
        })
        tid = resp.json()["id"]
        resp2 = client.post(f"/api/v1/transfers/{tid}/validate")
        assert resp2.status_code == 400
        assert "Insufficient stock" in resp2.json()["detail"]

    def test_transfer_creates_paired_ledger_entries(self, client):
        """Each transfer creates both TRANSFER_OUT and TRANSFER_IN entries."""
        seed_stock(client, product_id=1, quantity=100, location_id=1)

        resp = client.post("/api/v1/transfers/", json={
            "source_location_id": 1,
            "destination_location_id": 2,
            "items": [{"product_id": 1, "quantity": 25}],
        })
        client.post(f"/api/v1/transfers/{resp.json()['id']}/validate")

        history = client.get("/api/v1/stock/history/all?product_id=1&reference_type=transfer").json()
        types = {e["movement_type"] for e in history}
        assert "TRANSFER_OUT" in types
        assert "TRANSFER_IN" in types

        out_entry = next(e for e in history if e["movement_type"] == "TRANSFER_OUT")
        in_entry = next(e for e in history if e["movement_type"] == "TRANSFER_IN")
        assert out_entry["quantity"] == -25.0
        assert in_entry["quantity"] == 25.0

    def test_cancel_transfer(self, client):
        resp = client.post("/api/v1/transfers/", json={
            "source_location_id": 1,
            "destination_location_id": 2,
            "items": [{"product_id": 1, "quantity": 10}],
        })
        tid = resp.json()["id"]
        resp2 = client.post(f"/api/v1/transfers/{tid}/cancel")
        assert resp2.status_code == 200
        assert resp2.json()["status"] == "CANCELLED"
