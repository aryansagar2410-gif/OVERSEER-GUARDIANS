"""
Tests for Stock Adjustments — reconcile recorded vs physical count.

Key scenario from hackathon spec:
    Recorded = 100, Physical = 97
    Adjustment = -3
    New stock = 97
"""
from tests.conftest import seed_stock


class TestAdjustmentCRUD:

    def test_create_adjustment(self, client):
        resp = client.post("/api/v1/adjustments/", json={
            "location_id": 1,
            "reason": "Damaged",
            "items": [
                {"product_id": 1, "recorded_quantity": 100, "physical_quantity": 97},
            ],
        })
        assert resp.status_code == 201
        data = resp.json()
        assert data["status"] == "DRAFT"
        assert data["reference"].startswith("ADJ-")
        assert data["items"][0]["difference"] == -3.0

    def test_list_adjustments(self, client):
        client.post("/api/v1/adjustments/", json={
            "items": [{"product_id": 1, "recorded_quantity": 50, "physical_quantity": 48}],
        })
        resp = client.get("/api/v1/adjustments/")
        assert resp.status_code == 200
        assert len(resp.json()) == 1


class TestAdjustmentLifecycle:

    def test_adjustment_corrects_stock(self, client):
        """
        THE CORE TEST:
        Recorded = 100, Physical = 97
        Adjustment = -3
        New stock = 97
        """
        # Seed 100 units
        seed_stock(client, product_id=1, quantity=100)
        resp = client.get("/api/v1/stock/1")
        assert resp.json()["total_quantity"] == 100.0

        # Create adjustment: recorded 100, physical 97 → diff = -3
        resp = client.post("/api/v1/adjustments/", json={
            "location_id": 1,
            "reason": "Damaged",
            "notes": "3 units found damaged during count",
            "items": [
                {"product_id": 1, "recorded_quantity": 100, "physical_quantity": 97},
            ],
        })
        assert resp.status_code == 201
        aid = resp.json()["id"]
        assert resp.json()["items"][0]["difference"] == -3.0

        # Process the adjustment
        resp2 = client.post(f"/api/v1/adjustments/{aid}/validate")
        assert resp2.status_code == 200
        assert resp2.json()["status"] == "DONE"

        # Stock should now be 97
        resp3 = client.get("/api/v1/stock/1")
        assert resp3.json()["total_quantity"] == 97.0

    def test_positive_adjustment(self, client):
        """Found extra stock during count → stock increases."""
        seed_stock(client, product_id=1, quantity=50)

        resp = client.post("/api/v1/adjustments/", json={
            "location_id": 1,
            "reason": "Counting Error",
            "items": [
                {"product_id": 1, "recorded_quantity": 50, "physical_quantity": 55},
            ],
        })
        aid = resp.json()["id"]
        assert resp.json()["items"][0]["difference"] == 5.0

        client.post(f"/api/v1/adjustments/{aid}/validate")

        resp = client.get("/api/v1/stock/1")
        assert resp.json()["total_quantity"] == 55.0

    def test_zero_difference_skipped(self, client):
        """No ledger entry created when recorded == physical."""
        seed_stock(client, product_id=1, quantity=100)

        resp = client.post("/api/v1/adjustments/", json={
            "items": [
                {"product_id": 1, "recorded_quantity": 100, "physical_quantity": 100},
            ],
        })
        aid = resp.json()["id"]
        client.post(f"/api/v1/adjustments/{aid}/validate")

        # Stock unchanged
        resp = client.get("/api/v1/stock/1")
        assert resp.json()["total_quantity"] == 100.0

        # No adjustment ledger entry (only the receipt one)
        history = client.get("/api/v1/stock/history/all?product_id=1&reference_type=adjustment").json()
        assert len(history) == 0

    def test_adjustment_prevents_negative_stock(self, client):
        """Cannot adjust stock below zero."""
        seed_stock(client, product_id=1, quantity=10)

        resp = client.post("/api/v1/adjustments/", json={
            "location_id": 1,
            "reason": "Theft",
            "items": [
                {"product_id": 1, "recorded_quantity": 10, "physical_quantity": 0},
            ],
        })
        aid = resp.json()["id"]
        # This should succeed (diff = -10, current stock = 10, result = 0)
        resp2 = client.post(f"/api/v1/adjustments/{aid}/validate")
        assert resp2.status_code == 200

    def test_adjustment_blocks_below_zero(self, client):
        """Cannot adjust when result would be negative."""
        seed_stock(client, product_id=1, quantity=5)

        resp = client.post("/api/v1/adjustments/", json={
            "location_id": 1,
            "reason": "Error",
            "items": [
                # Claiming we had 20 but only have 5 → diff = -15
                # Current stock from ledger = 5, 5 + (-15) = -10 → should fail
                {"product_id": 1, "recorded_quantity": 20, "physical_quantity": 5},
            ],
        })
        aid = resp.json()["id"]
        resp2 = client.post(f"/api/v1/adjustments/{aid}/validate")
        assert resp2.status_code == 400
        assert "negative" in resp2.json()["detail"].lower()

    def test_cancel_adjustment(self, client):
        resp = client.post("/api/v1/adjustments/", json={
            "items": [{"product_id": 1, "recorded_quantity": 50, "physical_quantity": 48}],
        })
        aid = resp.json()["id"]
        resp2 = client.post(f"/api/v1/adjustments/{aid}/cancel")
        assert resp2.status_code == 200
        assert resp2.json()["status"] == "CANCELLED"

    def test_cannot_process_cancelled_adjustment(self, client):
        resp = client.post("/api/v1/adjustments/", json={
            "items": [{"product_id": 1, "recorded_quantity": 50, "physical_quantity": 48}],
        })
        aid = resp.json()["id"]
        client.post(f"/api/v1/adjustments/{aid}/cancel")
        resp2 = client.post(f"/api/v1/adjustments/{aid}/validate")
        assert resp2.status_code == 400

    def test_adjustment_ledger_entry(self, client):
        """Adjustment writes correct ledger entry."""
        seed_stock(client, product_id=7, quantity=100)

        resp = client.post("/api/v1/adjustments/", json={
            "location_id": 1,
            "reason": "Damaged",
            "items": [
                {"product_id": 7, "recorded_quantity": 100, "physical_quantity": 97},
            ],
        })
        client.post(f"/api/v1/adjustments/{resp.json()['id']}/validate")

        history = client.get("/api/v1/stock/history/all?product_id=7&reference_type=adjustment").json()
        assert len(history) == 1
        assert history[0]["movement_type"] == "ADJUSTMENT"
        assert history[0]["quantity"] == -3.0


class TestFullHackathonScenario:
    """
    End-to-end test replicating the EXACT hackathon spec:
    1. Receive 100 kg
    2. Transfer to another location (total unchanged)
    3. Deliver 20
    4. Adjust 3 damaged units
    """

    def test_full_flow(self, client):
        PRODUCT = 1
        LOC_MAIN = 1
        LOC_SECONDARY = 2

        # ── Step 1: Receive 100 ──
        seed_stock(client, product_id=PRODUCT, quantity=100, location_id=LOC_MAIN)
        resp = client.get(f"/api/v1/stock/{PRODUCT}")
        assert resp.json()["total_quantity"] == 100.0

        # ── Step 2: Transfer 40 from main → secondary ──
        resp = client.post("/api/v1/transfers/", json={
            "source_location_id": LOC_MAIN,
            "destination_location_id": LOC_SECONDARY,
            "items": [{"product_id": PRODUCT, "quantity": 40}],
        })
        client.post(f"/api/v1/transfers/{resp.json()['id']}/validate")

        # Total still 100
        resp = client.get(f"/api/v1/stock/{PRODUCT}")
        assert resp.json()["total_quantity"] == 100.0
        # Main = 60, Secondary = 40
        resp_main = client.get(f"/api/v1/stock/{PRODUCT}?location_id={LOC_MAIN}")
        resp_sec = client.get(f"/api/v1/stock/{PRODUCT}?location_id={LOC_SECONDARY}")
        assert resp_main.json()["total_quantity"] == 60.0
        assert resp_sec.json()["total_quantity"] == 40.0

        # ── Step 3: Deliver 20 from main ──
        resp = client.post("/api/v1/deliveries/", json={
            "customer_name": "End Customer",
            "items": [{"product_id": PRODUCT, "location_id": LOC_MAIN, "quantity_ordered": 20}],
        })
        client.post(f"/api/v1/deliveries/{resp.json()['id']}/validate")

        # Main = 40, Secondary = 40, Total = 80
        resp = client.get(f"/api/v1/stock/{PRODUCT}")
        assert resp.json()["total_quantity"] == 80.0

        # ── Step 4: Adjust 3 damaged at secondary ──
        resp = client.post("/api/v1/adjustments/", json={
            "location_id": LOC_SECONDARY,
            "reason": "Damaged",
            "items": [
                {"product_id": PRODUCT, "recorded_quantity": 40, "physical_quantity": 37},
            ],
        })
        client.post(f"/api/v1/adjustments/{resp.json()['id']}/validate")

        # Main = 40, Secondary = 37, Total = 77
        resp_main = client.get(f"/api/v1/stock/{PRODUCT}?location_id={LOC_MAIN}")
        resp_sec = client.get(f"/api/v1/stock/{PRODUCT}?location_id={LOC_SECONDARY}")
        resp_total = client.get(f"/api/v1/stock/{PRODUCT}")
        assert resp_main.json()["total_quantity"] == 40.0
        assert resp_sec.json()["total_quantity"] == 37.0
        assert resp_total.json()["total_quantity"] == 77.0

        # ── Verify full ledger ──
        history = client.get(f"/api/v1/stock/history/all?product_id={PRODUCT}").json()
        types = [e["movement_type"] for e in history]
        assert "RECEIPT" in types
        assert "TRANSFER_OUT" in types
        assert "TRANSFER_IN" in types
        assert "DELIVERY" in types
        assert "ADJUSTMENT" in types
