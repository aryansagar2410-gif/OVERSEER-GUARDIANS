"""
╔══════════════════════════════════════════════════════════════════════╗
║  StockSense — Inventory Operations Module (Single-File Edition)     ║
║  Member 2 — Inventory Operations Lead                               ║
║                                                                      ║
║  Receipts · Deliveries · Transfers · Adjustments · Ledger · History  ║
║                                                                      ║
║  Run:   uvicorn stocksense_inventory:app --reload                    ║
║  Docs:  http://localhost:8000/docs                                   ║
║  Test:  pytest stocksense_inventory.py -v                            ║
╚══════════════════════════════════════════════════════════════════════╝

Architecture:
    Every stock change → writes to central stock_ledger table
    Current stock = SUM(stock_ledger.quantity) WHERE product + location
    This keeps the math consistent everywhere.

Install:
    pip install fastapi uvicorn sqlalchemy pydantic pytest httpx
"""
from __future__ import annotations

import enum
from datetime import datetime, timezone
from typing import Optional

from fastapi import FastAPI, APIRouter, Depends, HTTPException, Query, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field, field_validator
from sqlalchemy import (
    Column, Integer, Float, String, Text, DateTime,
    ForeignKey, Enum as SQLEnum, create_engine, func,
)
from sqlalchemy.orm import (
    Session, relationship, sessionmaker, declarative_base,
)
from sqlalchemy.pool import StaticPool


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  DATABASE
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

SQLALCHEMY_DATABASE_URL = "sqlite:///./stocksense.db"

engine = create_engine(
    SQLALCHEMY_DATABASE_URL,
    connect_args={"check_same_thread": False},
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def get_db():
    """FastAPI dependency — yields a DB session and ensures cleanup."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def _utcnow():
    return datetime.now(timezone.utc)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  ENUMS
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

class MovementType(str, enum.Enum):
    """Type of stock movement recorded in the ledger."""
    RECEIPT = "RECEIPT"
    DELIVERY = "DELIVERY"
    TRANSFER_IN = "TRANSFER_IN"
    TRANSFER_OUT = "TRANSFER_OUT"
    ADJUSTMENT = "ADJUSTMENT"


class OperationStatus(str, enum.Enum):
    """Lifecycle status for any inventory operation."""
    DRAFT = "DRAFT"
    CONFIRMED = "CONFIRMED"
    DONE = "DONE"
    CANCELLED = "CANCELLED"


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  ORM MODELS  (11 tables)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# ── Central Ledger ─────────────────────────────────────────────────

class StockLedger(Base):
    """
    Single source of truth for all stock movements.
    +quantity = stock IN   (receipt, transfer-in, positive adjustment)
    -quantity = stock OUT  (delivery, transfer-out, negative adjustment)
    """
    __tablename__ = "stock_ledger"

    id = Column(Integer, primary_key=True, index=True)
    product_id = Column(Integer, nullable=False, index=True)
    location_id = Column(Integer, nullable=False, default=1, index=True)
    movement_type = Column(SQLEnum(MovementType), nullable=False, index=True)
    quantity = Column(Float, nullable=False)
    reference_type = Column(String(50), nullable=False)
    reference_id = Column(Integer, nullable=False)
    batch_number = Column(String(100), nullable=True)
    notes = Column(Text, nullable=True)
    created_by = Column(Integer, nullable=True)
    created_at = Column(DateTime, default=_utcnow)


# ── Receipts (vendor → warehouse, stock ↑) ────────────────────────

class Receipt(Base):
    __tablename__ = "receipts"

    id = Column(Integer, primary_key=True, index=True)
    reference = Column(String(50), unique=True, nullable=False, index=True)
    vendor_name = Column(String(200), nullable=False)
    status = Column(SQLEnum(OperationStatus), default=OperationStatus.DRAFT, nullable=False)
    scheduled_date = Column(DateTime, nullable=True)
    done_date = Column(DateTime, nullable=True)
    notes = Column(Text, nullable=True)
    created_by = Column(Integer, nullable=True)
    created_at = Column(DateTime, default=_utcnow)
    updated_at = Column(DateTime, default=_utcnow, onupdate=_utcnow)

    items = relationship("ReceiptItem", back_populates="receipt", cascade="all, delete-orphan")


class ReceiptItem(Base):
    __tablename__ = "receipt_items"

    id = Column(Integer, primary_key=True, index=True)
    receipt_id = Column(Integer, ForeignKey("receipts.id", ondelete="CASCADE"), nullable=False)
    product_id = Column(Integer, nullable=False)
    location_id = Column(Integer, nullable=False, default=1)
    quantity_expected = Column(Float, nullable=False)
    quantity_received = Column(Float, nullable=False, default=0)

    receipt = relationship("Receipt", back_populates="items")


# ── Delivery Orders (warehouse → customer, stock ↓) ───────────────

class DeliveryOrder(Base):
    __tablename__ = "delivery_orders"

    id = Column(Integer, primary_key=True, index=True)
    reference = Column(String(50), unique=True, nullable=False, index=True)
    customer_name = Column(String(200), nullable=False)
    status = Column(SQLEnum(OperationStatus), default=OperationStatus.DRAFT, nullable=False)
    scheduled_date = Column(DateTime, nullable=True)
    done_date = Column(DateTime, nullable=True)
    notes = Column(Text, nullable=True)
    created_by = Column(Integer, nullable=True)
    created_at = Column(DateTime, default=_utcnow)
    updated_at = Column(DateTime, default=_utcnow, onupdate=_utcnow)

    items = relationship("DeliveryItem", back_populates="delivery", cascade="all, delete-orphan")


class DeliveryItem(Base):
    __tablename__ = "delivery_items"

    id = Column(Integer, primary_key=True, index=True)
    delivery_id = Column(Integer, ForeignKey("delivery_orders.id", ondelete="CASCADE"), nullable=False)
    product_id = Column(Integer, nullable=False)
    location_id = Column(Integer, nullable=False, default=1)
    quantity_ordered = Column(Float, nullable=False)
    quantity_delivered = Column(Float, nullable=False, default=0)

    delivery = relationship("DeliveryOrder", back_populates="items")


# ── Internal Transfers (location A → B, total unchanged) ──────────

class InternalTransfer(Base):
    __tablename__ = "internal_transfers"

    id = Column(Integer, primary_key=True, index=True)
    reference = Column(String(50), unique=True, nullable=False, index=True)
    source_location_id = Column(Integer, nullable=False)
    destination_location_id = Column(Integer, nullable=False)
    status = Column(SQLEnum(OperationStatus), default=OperationStatus.DRAFT, nullable=False)
    scheduled_date = Column(DateTime, nullable=True)
    done_date = Column(DateTime, nullable=True)
    notes = Column(Text, nullable=True)
    created_by = Column(Integer, nullable=True)
    created_at = Column(DateTime, default=_utcnow)
    updated_at = Column(DateTime, default=_utcnow, onupdate=_utcnow)

    items = relationship("TransferItem", back_populates="transfer", cascade="all, delete-orphan")


class TransferItem(Base):
    __tablename__ = "transfer_items"

    id = Column(Integer, primary_key=True, index=True)
    transfer_id = Column(Integer, ForeignKey("internal_transfers.id", ondelete="CASCADE"), nullable=False)
    product_id = Column(Integer, nullable=False)
    quantity = Column(Float, nullable=False)

    transfer = relationship("InternalTransfer", back_populates="items")


# ── Stock Adjustments (reconcile recorded vs physical) ─────────────

class StockAdjustment(Base):
    __tablename__ = "stock_adjustments"

    id = Column(Integer, primary_key=True, index=True)
    reference = Column(String(50), unique=True, nullable=False, index=True)
    location_id = Column(Integer, nullable=False, default=1)
    status = Column(SQLEnum(OperationStatus), default=OperationStatus.DRAFT, nullable=False)
    adjustment_date = Column(DateTime, nullable=True)
    reason = Column(String(100), nullable=True)
    notes = Column(Text, nullable=True)
    created_by = Column(Integer, nullable=True)
    created_at = Column(DateTime, default=_utcnow)
    updated_at = Column(DateTime, default=_utcnow, onupdate=_utcnow)

    items = relationship("AdjustmentItem", back_populates="adjustment", cascade="all, delete-orphan")


class AdjustmentItem(Base):
    __tablename__ = "adjustment_items"

    id = Column(Integer, primary_key=True, index=True)
    adjustment_id = Column(Integer, ForeignKey("stock_adjustments.id", ondelete="CASCADE"), nullable=False)
    product_id = Column(Integer, nullable=False)
    recorded_quantity = Column(Float, nullable=False)
    physical_quantity = Column(Float, nullable=False)
    difference = Column(Float, nullable=False)

    adjustment = relationship("StockAdjustment", back_populates="items")


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  PYDANTIC SCHEMAS  (request / response)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# ── Ledger (read-only) ─────────────────────────────────────────────

class StockLedgerOut(BaseModel):
    id: int
    product_id: int
    location_id: int
    movement_type: str
    quantity: float
    reference_type: str
    reference_id: int
    batch_number: Optional[str] = None
    notes: Optional[str] = None
    created_by: Optional[int] = None
    created_at: Optional[datetime] = None
    model_config = {"from_attributes": True}


class StockSummaryOut(BaseModel):
    product_id: int
    location_id: Optional[int] = None
    total_quantity: float


# ── Receipt schemas ────────────────────────────────────────────────

class ReceiptItemCreate(BaseModel):
    product_id: int
    location_id: int = 1
    quantity_expected: float = Field(..., gt=0)
    quantity_received: float = Field(default=0, ge=0)


class ReceiptItemOut(BaseModel):
    id: int; receipt_id: int; product_id: int; location_id: int
    quantity_expected: float; quantity_received: float
    model_config = {"from_attributes": True}


class ReceiptCreate(BaseModel):
    vendor_name: str = Field(..., min_length=1, max_length=200)
    scheduled_date: Optional[datetime] = None
    notes: Optional[str] = None
    items: list[ReceiptItemCreate] = Field(..., min_length=1)


class ReceiptUpdate(BaseModel):
    vendor_name: Optional[str] = Field(None, min_length=1, max_length=200)
    scheduled_date: Optional[datetime] = None
    notes: Optional[str] = None


class ReceiptOut(BaseModel):
    id: int; reference: str; vendor_name: str; status: str
    scheduled_date: Optional[datetime] = None
    done_date: Optional[datetime] = None
    notes: Optional[str] = None
    created_by: Optional[int] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    items: list[ReceiptItemOut] = []
    model_config = {"from_attributes": True}


# ── Delivery schemas ──────────────────────────────────────────────

class DeliveryItemCreate(BaseModel):
    product_id: int
    location_id: int = 1
    quantity_ordered: float = Field(..., gt=0)
    quantity_delivered: float = Field(default=0, ge=0)


class DeliveryItemOut(BaseModel):
    id: int; delivery_id: int; product_id: int; location_id: int
    quantity_ordered: float; quantity_delivered: float
    model_config = {"from_attributes": True}


class DeliveryCreate(BaseModel):
    customer_name: str = Field(..., min_length=1, max_length=200)
    scheduled_date: Optional[datetime] = None
    notes: Optional[str] = None
    items: list[DeliveryItemCreate] = Field(..., min_length=1)


class DeliveryUpdate(BaseModel):
    customer_name: Optional[str] = Field(None, min_length=1, max_length=200)
    scheduled_date: Optional[datetime] = None
    notes: Optional[str] = None


class DeliveryOut(BaseModel):
    id: int; reference: str; customer_name: str; status: str
    scheduled_date: Optional[datetime] = None
    done_date: Optional[datetime] = None
    notes: Optional[str] = None
    created_by: Optional[int] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    items: list[DeliveryItemOut] = []
    model_config = {"from_attributes": True}


# ── Transfer schemas ──────────────────────────────────────────────

class TransferItemCreate(BaseModel):
    product_id: int
    quantity: float = Field(..., gt=0)


class TransferItemOut(BaseModel):
    id: int; transfer_id: int; product_id: int; quantity: float
    model_config = {"from_attributes": True}


class TransferCreate(BaseModel):
    source_location_id: int
    destination_location_id: int
    scheduled_date: Optional[datetime] = None
    notes: Optional[str] = None
    items: list[TransferItemCreate] = Field(..., min_length=1)

    @field_validator("destination_location_id")
    @classmethod
    def locations_must_differ(cls, v, info):
        if "source_location_id" in info.data and v == info.data["source_location_id"]:
            raise ValueError("Source and destination locations must be different")
        return v


class TransferUpdate(BaseModel):
    scheduled_date: Optional[datetime] = None
    notes: Optional[str] = None


class TransferOut(BaseModel):
    id: int; reference: str; source_location_id: int; destination_location_id: int; status: str
    scheduled_date: Optional[datetime] = None
    done_date: Optional[datetime] = None
    notes: Optional[str] = None
    created_by: Optional[int] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    items: list[TransferItemOut] = []
    model_config = {"from_attributes": True}


# ── Adjustment schemas ────────────────────────────────────────────

class AdjustmentItemCreate(BaseModel):
    product_id: int
    recorded_quantity: float = Field(..., ge=0)
    physical_quantity: float = Field(..., ge=0)


class AdjustmentItemOut(BaseModel):
    id: int; adjustment_id: int; product_id: int
    recorded_quantity: float; physical_quantity: float; difference: float
    model_config = {"from_attributes": True}


class AdjustmentCreate(BaseModel):
    location_id: int = 1
    reason: Optional[str] = Field(None, max_length=100)
    notes: Optional[str] = None
    items: list[AdjustmentItemCreate] = Field(..., min_length=1)


class AdjustmentUpdate(BaseModel):
    reason: Optional[str] = Field(None, max_length=100)
    notes: Optional[str] = None


class AdjustmentOut(BaseModel):
    id: int; reference: str; location_id: int; status: str
    adjustment_date: Optional[datetime] = None
    reason: Optional[str] = None
    notes: Optional[str] = None
    created_by: Optional[int] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    items: list[AdjustmentItemOut] = []
    model_config = {"from_attributes": True}


class MessageOut(BaseModel):
    detail: str


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  SERVICE LAYER — the BRAIN of all stock operations
#
#  Every method that changes stock:
#    1. Validates business rules
#    2. Updates the operation record
#    3. Writes to the central stock_ledger
#    4. Returns the updated object
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def _next_ref(db: Session, prefix: str, model) -> str:
    """Generate sequential reference: REC-00001, DEL-00002, etc."""
    last = db.query(func.max(model.id)).scalar() or 0
    return f"{prefix}-{last + 1:05d}"


# ── Stock queries (read from ledger) ──────────────────────────────

def get_stock(db: Session, product_id: int, location_id: Optional[int] = None) -> float:
    """Current stock for a product, optionally at a specific location."""
    q = db.query(func.coalesce(func.sum(StockLedger.quantity), 0.0)).filter(
        StockLedger.product_id == product_id,
    )
    if location_id is not None:
        q = q.filter(StockLedger.location_id == location_id)
    return float(q.scalar())


def get_stock_by_location(db: Session, product_id: int) -> dict[int, float]:
    rows = (
        db.query(StockLedger.location_id, func.sum(StockLedger.quantity))
        .filter(StockLedger.product_id == product_id)
        .group_by(StockLedger.location_id)
        .all()
    )
    return {loc: float(qty) for loc, qty in rows}


def get_all_stock(db: Session) -> list[dict]:
    rows = (
        db.query(
            StockLedger.product_id,
            StockLedger.location_id,
            func.sum(StockLedger.quantity).label("total"),
        )
        .group_by(StockLedger.product_id, StockLedger.location_id)
        .all()
    )
    return [
        {"product_id": r.product_id, "location_id": r.location_id, "total_quantity": float(r.total)}
        for r in rows
    ]


def validate_stock_available(db: Session, product_id: int, location_id: int, needed: float) -> None:
    """Raise 400 if there isn't enough stock."""
    available = get_stock(db, product_id, location_id)
    if available < needed:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                f"Insufficient stock for product {product_id} at location {location_id}: "
                f"available={available}, requested={needed}"
            ),
        )


# ── Movement history ──────────────────────────────────────────────

def get_movement_history(
    db: Session, *,
    product_id: Optional[int] = None, location_id: Optional[int] = None,
    movement_type: Optional[MovementType] = None, reference_type: Optional[str] = None,
    from_date: Optional[datetime] = None, to_date: Optional[datetime] = None,
    limit: int = 100, offset: int = 0,
) -> list[StockLedger]:
    q = db.query(StockLedger)
    if product_id is not None:
        q = q.filter(StockLedger.product_id == product_id)
    if location_id is not None:
        q = q.filter(StockLedger.location_id == location_id)
    if movement_type is not None:
        q = q.filter(StockLedger.movement_type == movement_type)
    if reference_type is not None:
        q = q.filter(StockLedger.reference_type == reference_type)
    if from_date is not None:
        q = q.filter(StockLedger.created_at >= from_date)
    if to_date is not None:
        q = q.filter(StockLedger.created_at <= to_date)
    return q.order_by(StockLedger.created_at.desc()).offset(offset).limit(limit).all()


# ═══════════════════════════════════════════════════════════════════
#  RECEIPTS  (stock IN)
# ═══════════════════════════════════════════════════════════════════

def svc_create_receipt(db: Session, data: ReceiptCreate, user_id: Optional[int] = None) -> Receipt:
    ref = _next_ref(db, "REC", Receipt)
    receipt = Receipt(
        reference=ref, vendor_name=data.vendor_name,
        scheduled_date=data.scheduled_date, notes=data.notes, created_by=user_id,
    )
    for item in data.items:
        receipt.items.append(ReceiptItem(
            product_id=item.product_id, location_id=item.location_id,
            quantity_expected=item.quantity_expected, quantity_received=item.quantity_received,
        ))
    db.add(receipt)
    db.commit()
    db.refresh(receipt)
    return receipt


def svc_get_receipt(db: Session, receipt_id: int) -> Receipt:
    receipt = db.query(Receipt).filter(Receipt.id == receipt_id).first()
    if not receipt:
        raise HTTPException(status_code=404, detail="Receipt not found")
    return receipt


def svc_list_receipts(db: Session, *, status_filter=None, limit=50, offset=0) -> list[Receipt]:
    q = db.query(Receipt)
    if status_filter:
        q = q.filter(Receipt.status == status_filter)
    return q.order_by(Receipt.created_at.desc()).offset(offset).limit(limit).all()


def svc_update_receipt(db: Session, receipt_id: int, data: ReceiptUpdate) -> Receipt:
    receipt = svc_get_receipt(db, receipt_id)
    if receipt.status != OperationStatus.DRAFT:
        raise HTTPException(400, "Can only update receipts in DRAFT status")
    for field, value in data.model_dump(exclude_unset=True).items():
        setattr(receipt, field, value)
    db.commit(); db.refresh(receipt)
    return receipt


def svc_confirm_receipt(db: Session, receipt_id: int) -> Receipt:
    receipt = svc_get_receipt(db, receipt_id)
    if receipt.status != OperationStatus.DRAFT:
        raise HTTPException(400, f"Cannot confirm receipt in {receipt.status.value} status")
    receipt.status = OperationStatus.CONFIRMED
    db.commit(); db.refresh(receipt)
    return receipt


def svc_process_receipt(db: Session, receipt_id: int) -> Receipt:
    """
    Validate receipt → DONE.
    Sets quantity_received = quantity_expected if not set, writes +qty ledger entries.
    """
    receipt = svc_get_receipt(db, receipt_id)
    if receipt.status not in (OperationStatus.CONFIRMED, OperationStatus.DRAFT):
        raise HTTPException(400, f"Cannot process receipt in {receipt.status.value} status")
    now = _utcnow()
    for item in receipt.items:
        if item.quantity_received == 0:
            item.quantity_received = item.quantity_expected
        db.add(StockLedger(
            product_id=item.product_id, location_id=item.location_id,
            movement_type=MovementType.RECEIPT, quantity=item.quantity_received,
            reference_type="receipt", reference_id=receipt.id,
            notes=f"Receipt {receipt.reference}", created_by=receipt.created_by, created_at=now,
        ))
    receipt.status = OperationStatus.DONE
    receipt.done_date = now
    db.commit(); db.refresh(receipt)
    return receipt


def svc_cancel_receipt(db: Session, receipt_id: int) -> Receipt:
    receipt = svc_get_receipt(db, receipt_id)
    if receipt.status == OperationStatus.DONE:
        raise HTTPException(400, "Cannot cancel a completed receipt")
    if receipt.status == OperationStatus.CANCELLED:
        raise HTTPException(400, "Receipt is already cancelled")
    receipt.status = OperationStatus.CANCELLED
    db.commit(); db.refresh(receipt)
    return receipt


# ═══════════════════════════════════════════════════════════════════
#  DELIVERY ORDERS  (stock OUT)
# ═══════════════════════════════════════════════════════════════════

def svc_create_delivery(db: Session, data: DeliveryCreate, user_id: Optional[int] = None) -> DeliveryOrder:
    ref = _next_ref(db, "DEL", DeliveryOrder)
    delivery = DeliveryOrder(
        reference=ref, customer_name=data.customer_name,
        scheduled_date=data.scheduled_date, notes=data.notes, created_by=user_id,
    )
    for item in data.items:
        delivery.items.append(DeliveryItem(
            product_id=item.product_id, location_id=item.location_id,
            quantity_ordered=item.quantity_ordered, quantity_delivered=item.quantity_delivered,
        ))
    db.add(delivery)
    db.commit(); db.refresh(delivery)
    return delivery


def svc_get_delivery(db: Session, delivery_id: int) -> DeliveryOrder:
    delivery = db.query(DeliveryOrder).filter(DeliveryOrder.id == delivery_id).first()
    if not delivery:
        raise HTTPException(status_code=404, detail="Delivery order not found")
    return delivery


def svc_list_deliveries(db: Session, *, status_filter=None, limit=50, offset=0) -> list[DeliveryOrder]:
    q = db.query(DeliveryOrder)
    if status_filter:
        q = q.filter(DeliveryOrder.status == status_filter)
    return q.order_by(DeliveryOrder.created_at.desc()).offset(offset).limit(limit).all()


def svc_update_delivery(db: Session, delivery_id: int, data: DeliveryUpdate) -> DeliveryOrder:
    delivery = svc_get_delivery(db, delivery_id)
    if delivery.status != OperationStatus.DRAFT:
        raise HTTPException(400, "Can only update deliveries in DRAFT status")
    for field, value in data.model_dump(exclude_unset=True).items():
        setattr(delivery, field, value)
    db.commit(); db.refresh(delivery)
    return delivery


def svc_confirm_delivery(db: Session, delivery_id: int) -> DeliveryOrder:
    delivery = svc_get_delivery(db, delivery_id)
    if delivery.status != OperationStatus.DRAFT:
        raise HTTPException(400, f"Cannot confirm delivery in {delivery.status.value} status")
    delivery.status = OperationStatus.CONFIRMED
    db.commit(); db.refresh(delivery)
    return delivery


def svc_process_delivery(db: Session, delivery_id: int) -> DeliveryOrder:
    """
    Validate delivery → DONE.
    Checks stock availability FIRST, then writes -qty ledger entries.
    """
    delivery = svc_get_delivery(db, delivery_id)
    if delivery.status not in (OperationStatus.CONFIRMED, OperationStatus.DRAFT):
        raise HTTPException(400, f"Cannot process delivery in {delivery.status.value} status")
    now = _utcnow()
    # Phase 1: validate all items
    for item in delivery.items:
        qty = item.quantity_delivered if item.quantity_delivered > 0 else item.quantity_ordered
        validate_stock_available(db, item.product_id, item.location_id, qty)
    # Phase 2: write ledger
    for item in delivery.items:
        if item.quantity_delivered == 0:
            item.quantity_delivered = item.quantity_ordered
        db.add(StockLedger(
            product_id=item.product_id, location_id=item.location_id,
            movement_type=MovementType.DELIVERY, quantity=-item.quantity_delivered,
            reference_type="delivery", reference_id=delivery.id,
            notes=f"Delivery {delivery.reference}", created_by=delivery.created_by, created_at=now,
        ))
    delivery.status = OperationStatus.DONE
    delivery.done_date = now
    db.commit(); db.refresh(delivery)
    return delivery


def svc_cancel_delivery(db: Session, delivery_id: int) -> DeliveryOrder:
    delivery = svc_get_delivery(db, delivery_id)
    if delivery.status == OperationStatus.DONE:
        raise HTTPException(400, "Cannot cancel a completed delivery")
    if delivery.status == OperationStatus.CANCELLED:
        raise HTTPException(400, "Delivery is already cancelled")
    delivery.status = OperationStatus.CANCELLED
    db.commit(); db.refresh(delivery)
    return delivery


# ═══════════════════════════════════════════════════════════════════
#  INTERNAL TRANSFERS  (location A → B, total unchanged)
# ═══════════════════════════════════════════════════════════════════

def svc_create_transfer(db: Session, data: TransferCreate, user_id: Optional[int] = None) -> InternalTransfer:
    ref = _next_ref(db, "TRF", InternalTransfer)
    transfer = InternalTransfer(
        reference=ref,
        source_location_id=data.source_location_id,
        destination_location_id=data.destination_location_id,
        scheduled_date=data.scheduled_date, notes=data.notes, created_by=user_id,
    )
    for item in data.items:
        transfer.items.append(TransferItem(product_id=item.product_id, quantity=item.quantity))
    db.add(transfer)
    db.commit(); db.refresh(transfer)
    return transfer


def svc_get_transfer(db: Session, transfer_id: int) -> InternalTransfer:
    transfer = db.query(InternalTransfer).filter(InternalTransfer.id == transfer_id).first()
    if not transfer:
        raise HTTPException(status_code=404, detail="Transfer not found")
    return transfer


def svc_list_transfers(db: Session, *, status_filter=None, limit=50, offset=0) -> list[InternalTransfer]:
    q = db.query(InternalTransfer)
    if status_filter:
        q = q.filter(InternalTransfer.status == status_filter)
    return q.order_by(InternalTransfer.created_at.desc()).offset(offset).limit(limit).all()


def svc_update_transfer(db: Session, transfer_id: int, data: TransferUpdate) -> InternalTransfer:
    transfer = svc_get_transfer(db, transfer_id)
    if transfer.status != OperationStatus.DRAFT:
        raise HTTPException(400, "Can only update transfers in DRAFT status")
    for field, value in data.model_dump(exclude_unset=True).items():
        setattr(transfer, field, value)
    db.commit(); db.refresh(transfer)
    return transfer


def svc_confirm_transfer(db: Session, transfer_id: int) -> InternalTransfer:
    transfer = svc_get_transfer(db, transfer_id)
    if transfer.status != OperationStatus.DRAFT:
        raise HTTPException(400, f"Cannot confirm transfer in {transfer.status.value} status")
    transfer.status = OperationStatus.CONFIRMED
    db.commit(); db.refresh(transfer)
    return transfer


def svc_process_transfer(db: Session, transfer_id: int) -> InternalTransfer:
    """
    Validate transfer → DONE.
    Creates PAIRED ledger entries:
        TRANSFER_OUT (−qty at source)
        TRANSFER_IN  (+qty at destination)
    Total stock is preserved.
    """
    transfer = svc_get_transfer(db, transfer_id)
    if transfer.status not in (OperationStatus.CONFIRMED, OperationStatus.DRAFT):
        raise HTTPException(400, f"Cannot process transfer in {transfer.status.value} status")
    now = _utcnow()
    # Phase 1: validate source stock
    for item in transfer.items:
        validate_stock_available(db, item.product_id, transfer.source_location_id, item.quantity)
    # Phase 2: paired ledger entries
    for item in transfer.items:
        db.add(StockLedger(
            product_id=item.product_id, location_id=transfer.source_location_id,
            movement_type=MovementType.TRANSFER_OUT, quantity=-item.quantity,
            reference_type="transfer", reference_id=transfer.id,
            notes=f"Transfer {transfer.reference} OUT", created_by=transfer.created_by, created_at=now,
        ))
        db.add(StockLedger(
            product_id=item.product_id, location_id=transfer.destination_location_id,
            movement_type=MovementType.TRANSFER_IN, quantity=item.quantity,
            reference_type="transfer", reference_id=transfer.id,
            notes=f"Transfer {transfer.reference} IN", created_by=transfer.created_by, created_at=now,
        ))
    transfer.status = OperationStatus.DONE
    transfer.done_date = now
    db.commit(); db.refresh(transfer)
    return transfer


def svc_cancel_transfer(db: Session, transfer_id: int) -> InternalTransfer:
    transfer = svc_get_transfer(db, transfer_id)
    if transfer.status == OperationStatus.DONE:
        raise HTTPException(400, "Cannot cancel a completed transfer")
    if transfer.status == OperationStatus.CANCELLED:
        raise HTTPException(400, "Transfer is already cancelled")
    transfer.status = OperationStatus.CANCELLED
    db.commit(); db.refresh(transfer)
    return transfer


# ═══════════════════════════════════════════════════════════════════
#  STOCK ADJUSTMENTS  (reconcile recorded ↔ physical)
# ═══════════════════════════════════════════════════════════════════

def svc_create_adjustment(db: Session, data: AdjustmentCreate, user_id: Optional[int] = None) -> StockAdjustment:
    ref = _next_ref(db, "ADJ", StockAdjustment)
    adjustment = StockAdjustment(
        reference=ref, location_id=data.location_id,
        reason=data.reason, notes=data.notes, created_by=user_id,
    )
    for item in data.items:
        diff = item.physical_quantity - item.recorded_quantity
        adjustment.items.append(AdjustmentItem(
            product_id=item.product_id,
            recorded_quantity=item.recorded_quantity,
            physical_quantity=item.physical_quantity,
            difference=diff,
        ))
    db.add(adjustment)
    db.commit(); db.refresh(adjustment)
    return adjustment


def svc_get_adjustment(db: Session, adjustment_id: int) -> StockAdjustment:
    adjustment = db.query(StockAdjustment).filter(StockAdjustment.id == adjustment_id).first()
    if not adjustment:
        raise HTTPException(status_code=404, detail="Adjustment not found")
    return adjustment


def svc_list_adjustments(db: Session, *, status_filter=None, limit=50, offset=0) -> list[StockAdjustment]:
    q = db.query(StockAdjustment)
    if status_filter:
        q = q.filter(StockAdjustment.status == status_filter)
    return q.order_by(StockAdjustment.created_at.desc()).offset(offset).limit(limit).all()


def svc_update_adjustment(db: Session, adjustment_id: int, data: AdjustmentUpdate) -> StockAdjustment:
    adjustment = svc_get_adjustment(db, adjustment_id)
    if adjustment.status != OperationStatus.DRAFT:
        raise HTTPException(400, "Can only update adjustments in DRAFT status")
    for field, value in data.model_dump(exclude_unset=True).items():
        setattr(adjustment, field, value)
    db.commit(); db.refresh(adjustment)
    return adjustment


def svc_process_adjustment(db: Session, adjustment_id: int) -> StockAdjustment:
    """
    Apply adjustment → DONE.
    Writes ledger entry with the *difference* (physical − recorded).
    diff > 0 → stock gained (found extra)
    diff < 0 → stock lost (damaged / stolen)
    """
    adjustment = svc_get_adjustment(db, adjustment_id)
    if adjustment.status == OperationStatus.DONE:
        raise HTTPException(400, "Adjustment already processed")
    if adjustment.status == OperationStatus.CANCELLED:
        raise HTTPException(400, "Cannot process a cancelled adjustment")
    now = _utcnow()
    for item in adjustment.items:
        if item.difference == 0:
            continue
        if item.difference < 0:
            current = get_stock(db, item.product_id, adjustment.location_id)
            if current + item.difference < 0:
                raise HTTPException(400,
                    f"Adjustment would make stock negative for product {item.product_id}: "
                    f"current={current}, adjustment={item.difference}")
        db.add(StockLedger(
            product_id=item.product_id, location_id=adjustment.location_id,
            movement_type=MovementType.ADJUSTMENT, quantity=item.difference,
            reference_type="adjustment", reference_id=adjustment.id,
            notes=f"Adjustment {adjustment.reference}: {adjustment.reason or 'N/A'}",
            created_by=adjustment.created_by, created_at=now,
        ))
    adjustment.status = OperationStatus.DONE
    adjustment.adjustment_date = now
    db.commit(); db.refresh(adjustment)
    return adjustment


def svc_cancel_adjustment(db: Session, adjustment_id: int) -> StockAdjustment:
    adjustment = svc_get_adjustment(db, adjustment_id)
    if adjustment.status == OperationStatus.DONE:
        raise HTTPException(400, "Cannot cancel a completed adjustment")
    if adjustment.status == OperationStatus.CANCELLED:
        raise HTTPException(400, "Adjustment is already cancelled")
    adjustment.status = OperationStatus.CANCELLED
    db.commit(); db.refresh(adjustment)
    return adjustment


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  API ROUTERS
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# ── Receipts ──────────────────────────────────────────────────────

receipt_router = APIRouter(prefix="/receipts", tags=["📥 Receipts"])


@receipt_router.post("/", response_model=ReceiptOut, status_code=201)
def create_receipt(data: ReceiptCreate, db: Session = Depends(get_db)):
    """Create a new receipt in DRAFT status."""
    return svc_create_receipt(db, data)


@receipt_router.get("/", response_model=list[ReceiptOut])
def list_receipts(
    status: Optional[OperationStatus] = Query(None),
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    db: Session = Depends(get_db),
):
    return svc_list_receipts(db, status_filter=status, limit=limit, offset=offset)


@receipt_router.get("/{receipt_id}", response_model=ReceiptOut)
def get_receipt(receipt_id: int, db: Session = Depends(get_db)):
    return svc_get_receipt(db, receipt_id)


@receipt_router.patch("/{receipt_id}", response_model=ReceiptOut)
def update_receipt(receipt_id: int, data: ReceiptUpdate, db: Session = Depends(get_db)):
    return svc_update_receipt(db, receipt_id, data)


@receipt_router.post("/{receipt_id}/confirm", response_model=ReceiptOut)
def confirm_receipt(receipt_id: int, db: Session = Depends(get_db)):
    """DRAFT → CONFIRMED."""
    return svc_confirm_receipt(db, receipt_id)


@receipt_router.post("/{receipt_id}/validate", response_model=ReceiptOut)
def validate_receipt(receipt_id: int, db: Session = Depends(get_db)):
    """Process receipt → DONE. Writes stock ledger entries (stock ↑)."""
    return svc_process_receipt(db, receipt_id)


@receipt_router.post("/{receipt_id}/cancel", response_model=ReceiptOut)
def cancel_receipt(receipt_id: int, db: Session = Depends(get_db)):
    return svc_cancel_receipt(db, receipt_id)


# ── Deliveries ────────────────────────────────────────────────────

delivery_router = APIRouter(prefix="/deliveries", tags=["📤 Delivery Orders"])


@delivery_router.post("/", response_model=DeliveryOut, status_code=201)
def create_delivery(data: DeliveryCreate, db: Session = Depends(get_db)):
    return svc_create_delivery(db, data)


@delivery_router.get("/", response_model=list[DeliveryOut])
def list_deliveries(
    status: Optional[OperationStatus] = Query(None),
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    db: Session = Depends(get_db),
):
    return svc_list_deliveries(db, status_filter=status, limit=limit, offset=offset)


@delivery_router.get("/{delivery_id}", response_model=DeliveryOut)
def get_delivery(delivery_id: int, db: Session = Depends(get_db)):
    return svc_get_delivery(db, delivery_id)


@delivery_router.patch("/{delivery_id}", response_model=DeliveryOut)
def update_delivery(delivery_id: int, data: DeliveryUpdate, db: Session = Depends(get_db)):
    return svc_update_delivery(db, delivery_id, data)


@delivery_router.post("/{delivery_id}/confirm", response_model=DeliveryOut)
def confirm_delivery(delivery_id: int, db: Session = Depends(get_db)):
    return svc_confirm_delivery(db, delivery_id)


@delivery_router.post("/{delivery_id}/validate", response_model=DeliveryOut)
def validate_delivery(delivery_id: int, db: Session = Depends(get_db)):
    """Process delivery → DONE. Checks stock, then writes -qty ledger entries (stock ↓)."""
    return svc_process_delivery(db, delivery_id)


@delivery_router.post("/{delivery_id}/cancel", response_model=DeliveryOut)
def cancel_delivery(delivery_id: int, db: Session = Depends(get_db)):
    return svc_cancel_delivery(db, delivery_id)


# ── Transfers ─────────────────────────────────────────────────────

transfer_router = APIRouter(prefix="/transfers", tags=["🔄 Internal Transfers"])


@transfer_router.post("/", response_model=TransferOut, status_code=201)
def create_transfer(data: TransferCreate, db: Session = Depends(get_db)):
    return svc_create_transfer(db, data)


@transfer_router.get("/", response_model=list[TransferOut])
def list_transfers(
    status: Optional[OperationStatus] = Query(None),
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    db: Session = Depends(get_db),
):
    return svc_list_transfers(db, status_filter=status, limit=limit, offset=offset)


@transfer_router.get("/{transfer_id}", response_model=TransferOut)
def get_transfer(transfer_id: int, db: Session = Depends(get_db)):
    return svc_get_transfer(db, transfer_id)


@transfer_router.patch("/{transfer_id}", response_model=TransferOut)
def update_transfer(transfer_id: int, data: TransferUpdate, db: Session = Depends(get_db)):
    return svc_update_transfer(db, transfer_id, data)


@transfer_router.post("/{transfer_id}/confirm", response_model=TransferOut)
def confirm_transfer(transfer_id: int, db: Session = Depends(get_db)):
    return svc_confirm_transfer(db, transfer_id)


@transfer_router.post("/{transfer_id}/validate", response_model=TransferOut)
def validate_transfer(transfer_id: int, db: Session = Depends(get_db)):
    """Process transfer → DONE. Paired TRANSFER_OUT/TRANSFER_IN ledger entries. Total unchanged."""
    return svc_process_transfer(db, transfer_id)


@transfer_router.post("/{transfer_id}/cancel", response_model=TransferOut)
def cancel_transfer(transfer_id: int, db: Session = Depends(get_db)):
    return svc_cancel_transfer(db, transfer_id)


# ── Adjustments ───────────────────────────────────────────────────

adjustment_router = APIRouter(prefix="/adjustments", tags=["⚖️ Stock Adjustments"])


@adjustment_router.post("/", response_model=AdjustmentOut, status_code=201)
def create_adjustment(data: AdjustmentCreate, db: Session = Depends(get_db)):
    return svc_create_adjustment(db, data)


@adjustment_router.get("/", response_model=list[AdjustmentOut])
def list_adjustments(
    status: Optional[OperationStatus] = Query(None),
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    db: Session = Depends(get_db),
):
    return svc_list_adjustments(db, status_filter=status, limit=limit, offset=offset)


@adjustment_router.get("/{adjustment_id}", response_model=AdjustmentOut)
def get_adjustment(adjustment_id: int, db: Session = Depends(get_db)):
    return svc_get_adjustment(db, adjustment_id)


@adjustment_router.patch("/{adjustment_id}", response_model=AdjustmentOut)
def update_adjustment(adjustment_id: int, data: AdjustmentUpdate, db: Session = Depends(get_db)):
    return svc_update_adjustment(db, adjustment_id, data)


@adjustment_router.post("/{adjustment_id}/validate", response_model=AdjustmentOut)
def validate_adjustment(adjustment_id: int, db: Session = Depends(get_db)):
    """Process adjustment → DONE. Writes diff (physical−recorded) to ledger."""
    return svc_process_adjustment(db, adjustment_id)


@adjustment_router.post("/{adjustment_id}/cancel", response_model=AdjustmentOut)
def cancel_adjustment(adjustment_id: int, db: Session = Depends(get_db)):
    return svc_cancel_adjustment(db, adjustment_id)


# ── Stock & History ───────────────────────────────────────────────

stock_router = APIRouter(prefix="/stock", tags=["📊 Stock & History"])


@stock_router.get("/", response_model=list[StockSummaryOut])
def api_get_all_stock(db: Session = Depends(get_db)):
    """Stock summary for all products across all locations."""
    return get_all_stock(db)


@stock_router.get("/history/all", response_model=list[StockLedgerOut])
def api_get_movement_history(
    product_id: Optional[int] = Query(None),
    location_id: Optional[int] = Query(None),
    movement_type: Optional[MovementType] = Query(None),
    reference_type: Optional[str] = Query(None),
    from_date: Optional[datetime] = Query(None),
    to_date: Optional[datetime] = Query(None),
    limit: int = Query(100, ge=1, le=500),
    offset: int = Query(0, ge=0),
    db: Session = Depends(get_db),
):
    """Filterable, paginated movement history from the central ledger."""
    return get_movement_history(
        db, product_id=product_id, location_id=location_id,
        movement_type=movement_type, reference_type=reference_type,
        from_date=from_date, to_date=to_date, limit=limit, offset=offset,
    )


@stock_router.get("/{product_id}", response_model=StockSummaryOut)
def api_get_product_stock(
    product_id: int, location_id: Optional[int] = Query(None),
    db: Session = Depends(get_db),
):
    """Current stock for a product (optionally at a location)."""
    qty = get_stock(db, product_id, location_id)
    return StockSummaryOut(product_id=product_id, location_id=location_id, total_quantity=qty)


@stock_router.get("/{product_id}/by-location")
def api_get_stock_by_location(product_id: int, db: Session = Depends(get_db)):
    """Stock broken down by location for a product."""
    breakdown = get_stock_by_location(db, product_id)
    return {
        "product_id": product_id,
        "locations": [{"location_id": loc, "quantity": qty} for loc, qty in breakdown.items()],
        "total": sum(breakdown.values()),
    }


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  FASTAPI APPLICATION
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="StockSense — Inventory Operations",
    description=(
        "Central inventory management API.\n\n"
        "**Core principle:** every stock change logs to one central ledger table.\n\n"
        "### Operations\n"
        "- **Receipts** — vendor stock in → stock ↑\n"
        "- **Deliveries** — stock out to customer → stock ↓\n"
        "- **Transfers** — move between locations → total unchanged\n"
        "- **Adjustments** — reconcile recorded vs physical count\n"
    ),
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(receipt_router, prefix="/api/v1")
app.include_router(delivery_router, prefix="/api/v1")
app.include_router(transfer_router, prefix="/api/v1")
app.include_router(adjustment_router, prefix="/api/v1")
app.include_router(stock_router, prefix="/api/v1")


@app.get("/", tags=["Health"])
def root():
    return {"status": "ok", "app": "StockSense Inventory", "version": "1.0.0"}


@app.get("/health", tags=["Health"])
def health():
    return {"status": "healthy"}


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  TESTS  (run: pytest stocksense_inventory.py -v)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

import pytest
from fastapi.testclient import TestClient


@pytest.fixture(autouse=True)
def _fresh_db():
    """Create fresh tables before each test, drop after."""
    test_engine = create_engine("sqlite://", connect_args={"check_same_thread": False}, poolclass=StaticPool)
    TestSession = sessionmaker(autocommit=False, autoflush=False, bind=test_engine)
    Base.metadata.create_all(bind=test_engine)

    def _override():
        s = TestSession()
        try:
            yield s
        finally:
            s.close()

    app.dependency_overrides[get_db] = _override
    yield
    Base.metadata.drop_all(bind=test_engine)
    app.dependency_overrides.clear()


@pytest.fixture
def client():
    with TestClient(app) as c:
        yield c


def seed_stock(c: TestClient, product_id: int, quantity: float, location_id: int = 1):
    """Helper: create + validate a receipt to add stock."""
    resp = c.post("/api/v1/receipts/", json={
        "vendor_name": "Seed Vendor",
        "items": [{"product_id": product_id, "location_id": location_id, "quantity_expected": quantity}],
    })
    assert resp.status_code == 201
    c.post(f"/api/v1/receipts/{resp.json()['id']}/validate")


# ── Receipt tests ─────────────────────────────────────────────────

class TestReceipt:
    def test_create_draft(self, client):
        resp = client.post("/api/v1/receipts/", json={
            "vendor_name": "Acme Supplies",
            "items": [{"product_id": 1, "quantity_expected": 50}, {"product_id": 2, "quantity_expected": 30}],
        })
        assert resp.status_code == 201
        assert resp.json()["status"] == "DRAFT"
        assert resp.json()["reference"].startswith("REC-")
        assert len(resp.json()["items"]) == 2

    def test_100_receive_50_equals_150(self, client):
        """100 → Receive 50 → 150"""
        seed_stock(client, product_id=1, quantity=100)
        assert client.get("/api/v1/stock/1").json()["total_quantity"] == 100.0

        resp = client.post("/api/v1/receipts/", json={
            "vendor_name": "Second Batch",
            "items": [{"product_id": 1, "quantity_expected": 50}],
        })
        client.post(f"/api/v1/receipts/{resp.json()['id']}/validate")
        assert client.get("/api/v1/stock/1").json()["total_quantity"] == 150.0

    def test_confirm_lifecycle(self, client):
        resp = client.post("/api/v1/receipts/", json={
            "vendor_name": "V", "items": [{"product_id": 1, "quantity_expected": 10}],
        })
        rid = resp.json()["id"]
        assert client.post(f"/api/v1/receipts/{rid}/confirm").json()["status"] == "CONFIRMED"

    def test_cancel(self, client):
        resp = client.post("/api/v1/receipts/", json={
            "vendor_name": "V", "items": [{"product_id": 1, "quantity_expected": 10}],
        })
        assert client.post(f"/api/v1/receipts/{resp.json()['id']}/cancel").json()["status"] == "CANCELLED"

    def test_cannot_cancel_done(self, client):
        seed_stock(client, product_id=99, quantity=10)
        receipts = client.get("/api/v1/receipts/").json()
        assert client.post(f"/api/v1/receipts/{receipts[0]['id']}/cancel").status_code == 400

    def test_ledger_entry(self, client):
        seed_stock(client, product_id=42, quantity=75)
        history = client.get("/api/v1/stock/history/all?product_id=42").json()
        assert history[0]["movement_type"] == "RECEIPT"
        assert history[0]["quantity"] == 75.0


# ── Delivery tests ────────────────────────────────────────────────

class TestDelivery:
    def test_150_deliver_20_equals_130(self, client):
        """150 → Deliver 20 → 130"""
        seed_stock(client, product_id=1, quantity=150)
        resp = client.post("/api/v1/deliveries/", json={
            "customer_name": "Big Buyer",
            "items": [{"product_id": 1, "quantity_ordered": 20}],
        })
        client.post(f"/api/v1/deliveries/{resp.json()['id']}/validate")
        assert client.get("/api/v1/stock/1").json()["total_quantity"] == 130.0

    def test_rejects_insufficient_stock(self, client):
        """Cannot deliver more than available."""
        seed_stock(client, product_id=1, quantity=10)
        resp = client.post("/api/v1/deliveries/", json={
            "customer_name": "Greedy", "items": [{"product_id": 1, "quantity_ordered": 50}],
        })
        resp2 = client.post(f"/api/v1/deliveries/{resp.json()['id']}/validate")
        assert resp2.status_code == 400
        assert "Insufficient stock" in resp2.json()["detail"]

    def test_multiple_deliveries_accumulate(self, client):
        seed_stock(client, product_id=1, quantity=100)
        for qty in [30, 25]:
            resp = client.post("/api/v1/deliveries/", json={
                "customer_name": "C", "items": [{"product_id": 1, "quantity_ordered": qty}],
            })
            client.post(f"/api/v1/deliveries/{resp.json()['id']}/validate")
        assert client.get("/api/v1/stock/1").json()["total_quantity"] == 45.0

    def test_negative_ledger_entry(self, client):
        seed_stock(client, product_id=5, quantity=50)
        resp = client.post("/api/v1/deliveries/", json={
            "customer_name": "C", "items": [{"product_id": 5, "quantity_ordered": 15}],
        })
        client.post(f"/api/v1/deliveries/{resp.json()['id']}/validate")
        h = client.get("/api/v1/stock/history/all?product_id=5&reference_type=delivery").json()
        assert h[0]["quantity"] == -15.0


# ── Transfer tests ────────────────────────────────────────────────

class TestTransfer:
    def test_a100_b50_transfer20_a80_b70_total150(self, client):
        """A:100 B:50 → Transfer 20 → A:80 B:70 TOTAL=150"""
        seed_stock(client, product_id=1, quantity=100, location_id=1)
        seed_stock(client, product_id=1, quantity=50, location_id=2)
        resp = client.post("/api/v1/transfers/", json={
            "source_location_id": 1, "destination_location_id": 2,
            "items": [{"product_id": 1, "quantity": 20}],
        })
        client.post(f"/api/v1/transfers/{resp.json()['id']}/validate")

        assert client.get("/api/v1/stock/1?location_id=1").json()["total_quantity"] == 80.0
        assert client.get("/api/v1/stock/1?location_id=2").json()["total_quantity"] == 70.0
        assert client.get("/api/v1/stock/1").json()["total_quantity"] == 150.0

    def test_reject_same_location(self, client):
        resp = client.post("/api/v1/transfers/", json={
            "source_location_id": 1, "destination_location_id": 1,
            "items": [{"product_id": 1, "quantity": 10}],
        })
        assert resp.status_code == 422

    def test_reject_insufficient_source(self, client):
        seed_stock(client, product_id=1, quantity=30, location_id=1)
        resp = client.post("/api/v1/transfers/", json={
            "source_location_id": 1, "destination_location_id": 2,
            "items": [{"product_id": 1, "quantity": 50}],
        })
        assert client.post(f"/api/v1/transfers/{resp.json()['id']}/validate").status_code == 400

    def test_paired_ledger_entries(self, client):
        seed_stock(client, product_id=1, quantity=100, location_id=1)
        resp = client.post("/api/v1/transfers/", json={
            "source_location_id": 1, "destination_location_id": 2,
            "items": [{"product_id": 1, "quantity": 25}],
        })
        client.post(f"/api/v1/transfers/{resp.json()['id']}/validate")
        h = client.get("/api/v1/stock/history/all?product_id=1&reference_type=transfer").json()
        types = {e["movement_type"] for e in h}
        assert types == {"TRANSFER_OUT", "TRANSFER_IN"}

    def test_by_location_breakdown(self, client):
        seed_stock(client, product_id=1, quantity=100, location_id=1)
        seed_stock(client, product_id=1, quantity=50, location_id=2)
        resp = client.post("/api/v1/transfers/", json={
            "source_location_id": 1, "destination_location_id": 2,
            "items": [{"product_id": 1, "quantity": 20}],
        })
        client.post(f"/api/v1/transfers/{resp.json()['id']}/validate")
        data = client.get("/api/v1/stock/1/by-location").json()
        assert data["total"] == 150.0


# ── Adjustment tests ──────────────────────────────────────────────

class TestAdjustment:
    def test_recorded100_physical97_equals_97(self, client):
        """Recorded=100, Physical=97 → Adjustment=-3 → New stock=97"""
        seed_stock(client, product_id=1, quantity=100)
        resp = client.post("/api/v1/adjustments/", json={
            "location_id": 1, "reason": "Damaged",
            "items": [{"product_id": 1, "recorded_quantity": 100, "physical_quantity": 97}],
        })
        assert resp.json()["items"][0]["difference"] == -3.0
        client.post(f"/api/v1/adjustments/{resp.json()['id']}/validate")
        assert client.get("/api/v1/stock/1").json()["total_quantity"] == 97.0

    def test_positive_adjustment(self, client):
        seed_stock(client, product_id=1, quantity=50)
        resp = client.post("/api/v1/adjustments/", json={
            "location_id": 1, "reason": "Counting Error",
            "items": [{"product_id": 1, "recorded_quantity": 50, "physical_quantity": 55}],
        })
        client.post(f"/api/v1/adjustments/{resp.json()['id']}/validate")
        assert client.get("/api/v1/stock/1").json()["total_quantity"] == 55.0

    def test_zero_diff_no_ledger(self, client):
        seed_stock(client, product_id=1, quantity=100)
        resp = client.post("/api/v1/adjustments/", json={
            "items": [{"product_id": 1, "recorded_quantity": 100, "physical_quantity": 100}],
        })
        client.post(f"/api/v1/adjustments/{resp.json()['id']}/validate")
        h = client.get("/api/v1/stock/history/all?product_id=1&reference_type=adjustment").json()
        assert len(h) == 0

    def test_blocks_negative_stock(self, client):
        seed_stock(client, product_id=1, quantity=5)
        resp = client.post("/api/v1/adjustments/", json={
            "location_id": 1, "reason": "Error",
            "items": [{"product_id": 1, "recorded_quantity": 20, "physical_quantity": 5}],
        })
        r = client.post(f"/api/v1/adjustments/{resp.json()['id']}/validate")
        assert r.status_code == 400
        assert "negative" in r.json()["detail"].lower()

    def test_cancel(self, client):
        resp = client.post("/api/v1/adjustments/", json={
            "items": [{"product_id": 1, "recorded_quantity": 50, "physical_quantity": 48}],
        })
        assert client.post(f"/api/v1/adjustments/{resp.json()['id']}/cancel").json()["status"] == "CANCELLED"


# ── Full hackathon end-to-end ─────────────────────────────────────

class TestFullHackathonScenario:
    """
    End-to-end: receive → transfer → deliver → adjust.
    Exactly as described in the hackathon spec / PDF.
    """
    def test_full_flow(self, client):
        P, A, B = 1, 1, 2

        # 1. Receive 100
        seed_stock(client, product_id=P, quantity=100, location_id=A)
        assert client.get(f"/api/v1/stock/{P}").json()["total_quantity"] == 100.0

        # 2. Transfer 40  A→B  (total unchanged)
        resp = client.post("/api/v1/transfers/", json={
            "source_location_id": A, "destination_location_id": B,
            "items": [{"product_id": P, "quantity": 40}],
        })
        client.post(f"/api/v1/transfers/{resp.json()['id']}/validate")
        assert client.get(f"/api/v1/stock/{P}").json()["total_quantity"] == 100.0
        assert client.get(f"/api/v1/stock/{P}?location_id={A}").json()["total_quantity"] == 60.0
        assert client.get(f"/api/v1/stock/{P}?location_id={B}").json()["total_quantity"] == 40.0

        # 3. Deliver 20 from A
        resp = client.post("/api/v1/deliveries/", json={
            "customer_name": "Customer",
            "items": [{"product_id": P, "location_id": A, "quantity_ordered": 20}],
        })
        client.post(f"/api/v1/deliveries/{resp.json()['id']}/validate")
        assert client.get(f"/api/v1/stock/{P}").json()["total_quantity"] == 80.0

        # 4. Adjust 3 damaged at B
        resp = client.post("/api/v1/adjustments/", json={
            "location_id": B, "reason": "Damaged",
            "items": [{"product_id": P, "recorded_quantity": 40, "physical_quantity": 37}],
        })
        client.post(f"/api/v1/adjustments/{resp.json()['id']}/validate")
        assert client.get(f"/api/v1/stock/{P}?location_id={A}").json()["total_quantity"] == 40.0
        assert client.get(f"/api/v1/stock/{P}?location_id={B}").json()["total_quantity"] == 37.0
        assert client.get(f"/api/v1/stock/{P}").json()["total_quantity"] == 77.0

        # 5. Verify full ledger has all movement types
        h = client.get(f"/api/v1/stock/history/all?product_id={P}").json()
        types = {e["movement_type"] for e in h}
        assert types == {"RECEIPT", "TRANSFER_OUT", "TRANSFER_IN", "DELIVERY", "ADJUSTMENT"}


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  ENTRY POINT
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

if __name__ == "__main__":
    import uvicorn
    print("\n🏭 StockSense Inventory — starting on http://localhost:8000")
    print("📄 API docs → http://localhost:8000/docs\n")
    uvicorn.run(app, host="0.0.0.0", port=8000)
