from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import Product, Supplier, Location
from ..schemas import (
    ProductCreate, ProductOut, 
    SupplierCreate, SupplierOut, 
    LocationCreate, LocationOut
)
from ..auth import get_manager, get_staff

router = APIRouter(tags=["📦 Master Data"])

# ──────────────────────────────────────────────
# Products
# ──────────────────────────────────────────────
@router.post("/products", response_model=ProductOut, status_code=201)
def create_product(data: ProductCreate, db: Session = Depends(get_db), current_user = Depends(get_manager)):
    if db.query(Product).filter(Product.sku == data.sku).first():
        raise HTTPException(status_code=400, detail="SKU already exists")
    if data.barcode and db.query(Product).filter(Product.barcode == data.barcode).first():
        raise HTTPException(status_code=400, detail="Barcode already exists")
        
    product = Product(**data.model_dump())
    db.add(product)
    db.commit()
    db.refresh(product)
    return product

@router.get("/products", response_model=list[ProductOut])
def list_products(
    search: Optional[str] = None,
    category: Optional[str] = None,
    supplier_id: Optional[int] = None,
    limit: int = 50, offset: int = 0,
    db: Session = Depends(get_db),
    current_user = Depends(get_staff)
):
    q = db.query(Product)
    if search:
        q = q.filter((Product.name.ilike(f"%{search}%")) | (Product.sku.ilike(f"%{search}%")) | (Product.barcode == search))
    if category:
        q = q.filter(Product.category == category)
    if supplier_id:
        q = q.filter(Product.supplier_id == supplier_id)
    return q.offset(offset).limit(limit).all()

@router.get("/products/{product_id}", response_model=ProductOut)
def get_product(product_id: int, db: Session = Depends(get_db), current_user = Depends(get_staff)):
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product: raise HTTPException(404, "Product not found")
    return product

@router.patch("/products/{product_id}", response_model=ProductOut)
def update_product(product_id: int, data: ProductCreate, db: Session = Depends(get_db), current_user = Depends(get_manager)):
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product: raise HTTPException(404, "Product not found")
    
    # Check uniqueness
    if data.sku != product.sku and db.query(Product).filter(Product.sku == data.sku).first():
        raise HTTPException(400, "SKU already exists")
        
    for k, v in data.model_dump(exclude_unset=True).items():
        setattr(product, k, v)
    db.commit()
    db.refresh(product)
    return product

# ──────────────────────────────────────────────
# Suppliers
# ──────────────────────────────────────────────
@router.post("/suppliers", response_model=SupplierOut, status_code=201)
def create_supplier(data: SupplierCreate, db: Session = Depends(get_db), current_user = Depends(get_manager)):
    supplier = Supplier(**data.model_dump())
    db.add(supplier)
    db.commit()
    db.refresh(supplier)
    return supplier

@router.get("/suppliers", response_model=list[SupplierOut])
def list_suppliers(limit: int = 50, offset: int = 0, db: Session = Depends(get_db), current_user = Depends(get_staff)):
    return db.query(Supplier).offset(offset).limit(limit).all()

# ──────────────────────────────────────────────
# Locations
# ──────────────────────────────────────────────
@router.post("/locations", response_model=LocationOut, status_code=201)
def create_location(data: LocationCreate, db: Session = Depends(get_db), current_user = Depends(get_manager)):
    if db.query(Location).filter(Location.code == data.code).first():
        raise HTTPException(400, "Location code exists")
    loc = Location(**data.model_dump())
    db.add(loc)
    db.commit()
    db.refresh(loc)
    return loc

@router.get("/locations", response_model=list[LocationOut])
def list_locations(limit: int = 50, offset: int = 0, db: Session = Depends(get_db), current_user = Depends(get_staff)):
    return db.query(Location).offset(offset).limit(limit).all()
