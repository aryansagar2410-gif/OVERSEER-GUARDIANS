from __future__ import annotations
from datetime import datetime, date
from typing import Optional, List
from pydantic import BaseModel, Field, field_validator, EmailStr

# ──────────────────────────────────────────────
# Users & Auth
# ──────────────────────────────────────────────
class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    username: Optional[str] = None
    role: Optional[str] = None

class UserCreate(BaseModel):
    email: EmailStr
    username: str
    password: str
    role: Optional[str] = "VIEWER"

class UserOut(BaseModel):
    id: int
    email: str
    username: str
    role: str
    is_active: bool
    model_config = {"from_attributes": True}

# ──────────────────────────────────────────────
# Master Data (Supplier, Location, Product)
# ──────────────────────────────────────────────
class SupplierCreate(BaseModel):
    name: str
    contact_person: Optional[str] = None
    email: Optional[EmailStr] = None
    phone: Optional[str] = None
    address: Optional[str] = None
    tax_number: Optional[str] = None
    notes: Optional[str] = None

class SupplierOut(SupplierCreate):
    id: int
    is_active: bool
    model_config = {"from_attributes": True}

class LocationCreate(BaseModel):
    name: str
    code: str
    address: Optional[str] = None
    type: Optional[str] = "WAREHOUSE"

class LocationOut(LocationCreate):
    id: int
    is_active: bool
    model_config = {"from_attributes": True}

class ProductCreate(BaseModel):
    sku: str
    name: str
    barcode: Optional[str] = None
    description: Optional[str] = None
    category: Optional[str] = None
    brand: Optional[str] = None
    uom: Optional[str] = "pcs"
    cost_price: Optional[float] = 0.0
    selling_price: Optional[float] = 0.0
    min_stock_level: Optional[float] = 0.0
    max_stock_level: Optional[float] = 0.0
    reorder_level: Optional[float] = 0.0
    supplier_id: Optional[int] = None

class ProductOut(ProductCreate):
    id: int
    is_active: bool
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    model_config = {"from_attributes": True}

# ──────────────────────────────────────────────
# Stock Ledger
# ──────────────────────────────────────────────
class StockLedgerOut(BaseModel):
    id: int
    product_id: int
    location_id: int
    movement_type: str
    quantity_before: float
    quantity: float
    quantity_after: float
    reference_type: str
    reference_id: int
    batch_number: Optional[str] = None
    expiry_date: Optional[date] = None
    notes: Optional[str] = None
    reason: Optional[str] = None
    created_by: Optional[int] = None
    created_at: Optional[datetime] = None
    model_config = {"from_attributes": True}

class StockSummaryOut(BaseModel):
    product_id: int
    location_id: Optional[int] = None
    total_quantity: float
    status: Optional[str] = None # LOW_STOCK, OUT_OF_STOCK, NORMAL

# ──────────────────────────────────────────────
# Receipts
# ──────────────────────────────────────────────
class ReceiptItemCreate(BaseModel):
    product_id: int
    location_id: int = 1
    quantity_expected: float = Field(..., gt=0)
    quantity_received: float = Field(default=0, ge=0)
    unit_price: Optional[float] = None
    batch_number: Optional[str] = None
    expiry_date: Optional[date] = None

class ReceiptItemOut(BaseModel):
    id: int
    receipt_id: int
    product_id: int
    location_id: int
    quantity_expected: float
    quantity_received: float
    unit_price: Optional[float] = None
    batch_number: Optional[str] = None
    expiry_date: Optional[date] = None
    model_config = {"from_attributes": True}

class ReceiptCreate(BaseModel):
    vendor_name: Optional[str] = None
    supplier_id: Optional[int] = None
    scheduled_date: Optional[datetime] = None
    notes: Optional[str] = None
    items: list[ReceiptItemCreate] = Field(..., min_length=1)

class ReceiptUpdate(BaseModel):
    vendor_name: Optional[str] = None
    supplier_id: Optional[int] = None
    scheduled_date: Optional[datetime] = None
    notes: Optional[str] = None

class ReceiptOut(BaseModel):
    id: int
    reference: str
    vendor_name: Optional[str] = None
    supplier_id: Optional[int] = None
    status: str
    scheduled_date: Optional[datetime] = None
    done_date: Optional[datetime] = None
    notes: Optional[str] = None
    created_by: Optional[int] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    items: list[ReceiptItemOut] = []
    model_config = {"from_attributes": True}

# ──────────────────────────────────────────────
# Delivery Order
# ──────────────────────────────────────────────
class DeliveryItemCreate(BaseModel):
    product_id: int
    location_id: int = 1
    quantity_ordered: float = Field(..., gt=0)
    quantity_delivered: float = Field(default=0, ge=0)

class DeliveryItemOut(BaseModel):
    id: int
    delivery_id: int
    product_id: int
    location_id: int
    quantity_ordered: float
    quantity_delivered: float
    model_config = {"from_attributes": True}

class DeliveryCreate(BaseModel):
    customer_name: str = Field(..., min_length=1, max_length=200)
    scheduled_date: Optional[datetime] = None
    notes: Optional[str] = None
    items: list[DeliveryItemCreate] = Field(..., min_length=1)

class DeliveryUpdate(BaseModel):
    customer_name: Optional[str] = Field(None, min_length=1, max_length=200)
    scheduled_date: Optional[datetime] = None
    notes: Optional[str] = None

class DeliveryOut(BaseModel):
    id: int
    reference: str
    customer_name: str
    status: str
    scheduled_date: Optional[datetime] = None
    done_date: Optional[datetime] = None
    notes: Optional[str] = None
    created_by: Optional[int] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    items: list[DeliveryItemOut] = []
    model_config = {"from_attributes": True}

# ──────────────────────────────────────────────
# Internal Transfer
# ──────────────────────────────────────────────
class TransferItemCreate(BaseModel):
    product_id: int
    quantity: float = Field(..., gt=0)

class TransferItemOut(BaseModel):
    id: int
    transfer_id: int
    product_id: int
    quantity: float
    model_config = {"from_attributes": True}

class TransferCreate(BaseModel):
    source_location_id: int
    destination_location_id: int
    scheduled_date: Optional[datetime] = None
    notes: Optional[str] = None
    items: list[TransferItemCreate] = Field(..., min_length=1)

    @field_validator("destination_location_id")
    @classmethod
    def locations_must_differ(cls, v, info):
        if "source_location_id" in info.data and v == info.data["source_location_id"]:
            raise ValueError("Source and destination locations must be different")
        return v

class TransferUpdate(BaseModel):
    scheduled_date: Optional[datetime] = None
    notes: Optional[str] = None

class TransferOut(BaseModel):
    id: int
    reference: str
    source_location_id: int
    destination_location_id: int
    status: str
    scheduled_date: Optional[datetime] = None
    done_date: Optional[datetime] = None
    notes: Optional[str] = None
    created_by: Optional[int] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    items: list[TransferItemOut] = []
    model_config = {"from_attributes": True}

# ──────────────────────────────────────────────
# Stock Adjustment
# ──────────────────────────────────────────────
class AdjustmentItemCreate(BaseModel):
    product_id: int
    recorded_quantity: float = Field(..., ge=0)
    physical_quantity: float = Field(..., ge=0)

class AdjustmentItemOut(BaseModel):
    id: int
    adjustment_id: int
    product_id: int
    recorded_quantity: float
    physical_quantity: float
    difference: float
    model_config = {"from_attributes": True}

class AdjustmentCreate(BaseModel):
    location_id: int = 1
    reason: Optional[str] = Field(None, max_length=100)
    notes: Optional[str] = None
    items: list[AdjustmentItemCreate] = Field(..., min_length=1)

class AdjustmentUpdate(BaseModel):
    reason: Optional[str] = Field(None, max_length=100)
    notes: Optional[str] = None

class AdjustmentOut(BaseModel):
    id: int
    reference: str
    location_id: int
    status: str
    adjustment_date: Optional[datetime] = None
    reason: Optional[str] = None
    notes: Optional[str] = None
    created_by: Optional[int] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    items: list[AdjustmentItemOut] = []
    model_config = {"from_attributes": True}

# ──────────────────────────────────────────────
# Returns
# ──────────────────────────────────────────────
class ReturnItemCreate(BaseModel):
    product_id: int
    location_id: int = 1
    quantity: float = Field(..., gt=0)
    reason: Optional[str] = None

class ReturnItemOut(BaseModel):
    id: int
    return_id: int
    product_id: int
    location_id: int
    quantity: float
    reason: Optional[str] = None
    model_config = {"from_attributes": True}

class ReturnCreate(BaseModel):
    return_type: str # CUSTOMER or SUPPLIER
    customer_or_supplier_name: Optional[str] = None
    notes: Optional[str] = None
    items: list[ReturnItemCreate] = Field(..., min_length=1)

class ReturnOut(BaseModel):
    id: int
    reference: str
    return_type: str
    status: str
    customer_or_supplier_name: Optional[str] = None
    done_date: Optional[datetime] = None
    notes: Optional[str] = None
    created_by: Optional[int] = None
    created_at: Optional[datetime] = None
    items: list[ReturnItemOut] = []
    model_config = {"from_attributes": True}

# ──────────────────────────────────────────────
# Audit Log
# ──────────────────────────────────────────────
class AuditLogOut(BaseModel):
    id: int
    user_id: Optional[int] = None
    action: str
    resource: str
    resource_id: Optional[int] = None
    prev_value: Optional[str] = None
    new_value: Optional[str] = None
    ip_address: Optional[str] = None
    created_at: Optional[datetime] = None
    model_config = {"from_attributes": True}

class MessageOut(BaseModel):
    detail: str
