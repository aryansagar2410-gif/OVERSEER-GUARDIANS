from datetime import datetime, date
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func
from ..database import get_db
from ..models import Product, Location, Supplier, StockLedger, MovementType, Receipt, DeliveryOrder, User
from ..auth import get_staff

router = APIRouter(prefix="/dashboard", tags=["📈 Dashboard & Analytics"])

@router.get("/stats")
def get_dashboard_stats(db: Session = Depends(get_db), current_user: User = Depends(get_staff)):
    total_products = db.query(Product).count()
    total_locations = db.query(Location).count()
    total_suppliers = db.query(Supplier).count()
    
    # Calculate stock stats
    stock_rows = db.query(
        StockLedger.product_id, 
        func.sum(StockLedger.quantity).label("qty")
    ).group_by(StockLedger.product_id).all()
    
    total_stock_units = sum(r.qty for r in stock_rows)
    
    # Low stock
    low_stock_count = 0
    out_of_stock_count = 0
    for r in stock_rows:
        product = db.query(Product).filter(Product.id == r.product_id).first()
        if product:
            if r.qty <= 0:
                out_of_stock_count += 1
            elif r.qty <= product.reorder_level:
                low_stock_count += 1
                
    today = date.today()
    today_receipts = db.query(Receipt).filter(func.date(Receipt.created_at) == today).count()
    today_deliveries = db.query(DeliveryOrder).filter(func.date(DeliveryOrder.created_at) == today).count()

    return {
        "total_products": total_products,
        "total_locations": total_locations,
        "total_suppliers": total_suppliers,
        "total_stock_units": total_stock_units,
        "low_stock_products": low_stock_count,
        "out_of_stock_products": out_of_stock_count,
        "today_receipts": today_receipts,
        "today_deliveries": today_deliveries
    }
