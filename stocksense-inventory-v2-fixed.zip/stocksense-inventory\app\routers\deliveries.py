from typing import Optional
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import OperationStatus, User
from ..schemas import DeliveryCreate, DeliveryUpdate, DeliveryOut
from ..services import inventory_service as svc
from ..auth import get_staff, get_manager

router = APIRouter(prefix="/deliveries", tags=["📤 Delivery Orders"])

@router.post("/", response_model=DeliveryOut, status_code=201)
def create_delivery(data: DeliveryCreate, db: Session = Depends(get_db), current_user: User = Depends(get_manager)):
    return svc.create_delivery(db, data, user_id=current_user.id)

@router.get("/", response_model=list[DeliveryOut])
def list_deliveries(
    status: Optional[OperationStatus] = Query(None),
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_staff)
):
    return svc.list_deliveries(db, status_filter=status, limit=limit, offset=offset)

@router.get("/{delivery_id}", response_model=DeliveryOut)
def get_delivery(delivery_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_staff)):
    return svc.get_delivery(db, delivery_id)

@router.patch("/{delivery_id}", response_model=DeliveryOut)
def update_delivery(delivery_id: int, data: DeliveryUpdate, db: Session = Depends(get_db), current_user: User = Depends(get_manager)):
    return svc.update_delivery(db, delivery_id, data)

@router.post("/{delivery_id}/confirm", response_model=DeliveryOut)
def confirm_delivery(delivery_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_manager)):
    return svc.confirm_delivery(db, delivery_id)

@router.post("/{delivery_id}/validate", response_model=DeliveryOut)
def validate_delivery(delivery_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_manager)):
    return svc.process_delivery(db, delivery_id, user_id=current_user.id)

@router.post("/{delivery_id}/cancel", response_model=DeliveryOut)
def cancel_delivery(delivery_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_manager)):
    return svc.cancel_delivery(db, delivery_id)
