from typing import Optional
from datetime import datetime
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import MovementType, User
from ..schemas import StockLedgerOut, StockSummaryOut
from ..services import inventory_service as svc
from ..auth import get_staff

router = APIRouter(prefix="/stock", tags=["📊 Stock & History"])

@router.get("/", response_model=list[StockSummaryOut])
def get_all_stock(db: Session = Depends(get_db), current_user: User = Depends(get_staff)):
    return svc.get_all_stock(db)

@router.get("/history/all", response_model=list[StockLedgerOut])
def get_movement_history(
    product_id: Optional[int] = Query(None),
    location_id: Optional[int] = Query(None),
    movement_type: Optional[MovementType] = Query(None),
    reference_type: Optional[str] = Query(None),
    from_date: Optional[datetime] = Query(None),
    to_date: Optional[datetime] = Query(None),
    limit: int = Query(100, ge=1, le=500),
    offset: int = Query(0, ge=0),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_staff)
):
    return svc.get_movement_history(
        db, product_id=product_id, location_id=location_id,
        movement_type=movement_type, reference_type=reference_type,
        from_date=from_date, to_date=to_date, limit=limit, offset=offset,
    )

@router.get("/{product_id}", response_model=StockSummaryOut)
def get_product_stock(
    product_id: int,
    location_id: Optional[int] = Query(None),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_staff)
):
    qty = svc.get_stock(db, product_id, location_id)
    return StockSummaryOut(product_id=product_id, location_id=location_id, total_quantity=qty)

@router.get("/{product_id}/by-location")
def get_stock_by_location(product_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_staff)):
    breakdown = svc.get_stock_by_location(db, product_id)
    return {
        "product_id": product_id,
        "locations": [{"location_id": loc, "quantity": qty} for loc, qty in breakdown.items()],
        "total": sum(breakdown.values()),
    }
