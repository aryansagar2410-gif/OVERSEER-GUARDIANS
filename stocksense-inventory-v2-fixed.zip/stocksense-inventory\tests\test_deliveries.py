"""
Tests for Delivery Orders — stock goes out, stock ↓.

Key scenario from hackathon spec:
    150 → Deliver 20 → 130
"""
from tests.conftest import seed_stock


class TestDeliveryCRUD:

    def test_create_delivery(self, client):
        resp = client.post("/api/v1/deliveries/", json={
            "customer_name": "Customer Corp",
            "items": [
                {"product_id": 1, "quantity_ordered": 20},
            ],
        })
        assert resp.status_code == 201
        data = resp.json()
        assert data["status"] == "DRAFT"
        assert data["reference"].startswith("DEL-")

    def test_list_deliveries(self, client):
        client.post("/api/v1/deliveries/", json={
            "customer_name": "C1",
            "items": [{"product_id": 1, "quantity_ordered": 5}],
        })
        resp = client.get("/api/v1/deliveries/")
        assert resp.status_code == 200
        assert len(resp.json()) == 1


class TestDeliveryLifecycle:

    def test_deliver_decreases_stock(self, client):
        """
        THE CORE TEST:
        Start with 150, deliver 20 → stock = 130.
        """
        # Seed 150
        seed_stock(client, product_id=1, quantity=150)
        resp = client.get("/api/v1/stock/1")
        assert resp.json()["total_quantity"] == 150.0

        # Create delivery of 20
        resp = client.post("/api/v1/deliveries/", json={
            "customer_name": "Big Buyer",
            "items": [{"product_id": 1, "quantity_ordered": 20}],
        })
        did = resp.json()["id"]

        # Process delivery
        resp2 = client.post(f"/api/v1/deliveries/{did}/validate")
        assert resp2.status_code == 200
        assert resp2.json()["status"] == "DONE"

        # Stock should be 130
        resp3 = client.get("/api/v1/stock/1")
        assert resp3.json()["total_quantity"] == 130.0

    def test_delivery_rejects_insufficient_stock(self, client):
        """Cannot deliver more than available stock."""
        seed_stock(client, product_id=1, quantity=10)

        resp = client.post("/api/v1/deliveries/", json={
            "customer_name": "Greedy Customer",
            "items": [{"product_id": 1, "quantity_ordered": 50}],
        })
        did = resp.json()["id"]

        resp2 = client.post(f"/api/v1/deliveries/{did}/validate")
        assert resp2.status_code == 400
        assert "Insufficient stock" in resp2.json()["detail"]

    def test_delivery_rejects_zero_stock(self, client):
        """Cannot deliver when stock is zero."""
        resp = client.post("/api/v1/deliveries/", json={
            "customer_name": "No Stock Customer",
            "items": [{"product_id": 999, "quantity_ordered": 1}],
        })
        did = resp.json()["id"]
        resp2 = client.post(f"/api/v1/deliveries/{did}/validate")
        assert resp2.status_code == 400

    def test_multiple_deliveries_accumulate(self, client):
        """Multiple deliveries reduce stock cumulatively."""
        seed_stock(client, product_id=1, quantity=100)

        # Deliver 30
        resp = client.post("/api/v1/deliveries/", json={
            "customer_name": "C1",
            "items": [{"product_id": 1, "quantity_ordered": 30}],
        })
        client.post(f"/api/v1/deliveries/{resp.json()['id']}/validate")

        # Deliver 25
        resp = client.post("/api/v1/deliveries/", json={
            "customer_name": "C2",
            "items": [{"product_id": 1, "quantity_ordered": 25}],
        })
        client.post(f"/api/v1/deliveries/{resp.json()['id']}/validate")

        # Stock = 100 - 30 - 25 = 45
        resp = client.get("/api/v1/stock/1")
        assert resp.json()["total_quantity"] == 45.0

    def test_cancel_delivery(self, client):
        resp = client.post("/api/v1/deliveries/", json={
            "customer_name": "Cancel Me",
            "items": [{"product_id": 1, "quantity_ordered": 10}],
        })
        did = resp.json()["id"]
        resp2 = client.post(f"/api/v1/deliveries/{did}/cancel")
        assert resp2.status_code == 200
        assert resp2.json()["status"] == "CANCELLED"

    def test_delivery_creates_negative_ledger_entry(self, client):
        """Ledger entry should have negative quantity for deliveries."""
        seed_stock(client, product_id=5, quantity=50)
        resp = client.post("/api/v1/deliveries/", json={
            "customer_name": "Ledger Test",
            "items": [{"product_id": 5, "quantity_ordered": 15}],
        })
        client.post(f"/api/v1/deliveries/{resp.json()['id']}/validate")

        history = client.get("/api/v1/stock/history/all?product_id=5&reference_type=delivery").json()
        assert len(history) == 1
        assert history[0]["quantity"] == -15.0
        assert history[0]["movement_type"] == "DELIVERY"
