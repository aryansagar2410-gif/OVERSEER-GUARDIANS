from typing import Optional
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import OperationStatus, User
from ..schemas import TransferCreate, TransferUpdate, TransferOut
from ..services import inventory_service as svc
from ..auth import get_staff, get_manager

router = APIRouter(prefix="/transfers", tags=["🔄 Internal Transfers"])

@router.post("/", response_model=TransferOut, status_code=201)
def create_transfer(data: TransferCreate, db: Session = Depends(get_db), current_user: User = Depends(get_manager)):
    return svc.create_transfer(db, data, user_id=current_user.id)

@router.get("/", response_model=list[TransferOut])
def list_transfers(
    status: Optional[OperationStatus] = Query(None),
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_staff)
):
    return svc.list_transfers(db, status_filter=status, limit=limit, offset=offset)

@router.get("/{transfer_id}", response_model=TransferOut)
def get_transfer(transfer_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_staff)):
    return svc.get_transfer(db, transfer_id)

@router.patch("/{transfer_id}", response_model=TransferOut)
def update_transfer(transfer_id: int, data: TransferUpdate, db: Session = Depends(get_db), current_user: User = Depends(get_manager)):
    return svc.update_transfer(db, transfer_id, data)

@router.post("/{transfer_id}/confirm", response_model=TransferOut)
def confirm_transfer(transfer_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_manager)):
    return svc.confirm_transfer(db, transfer_id)

@router.post("/{transfer_id}/validate", response_model=TransferOut)
def validate_transfer(transfer_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_manager)):
    return svc.process_transfer(db, transfer_id, user_id=current_user.id)

@router.post("/{transfer_id}/cancel", response_model=TransferOut)
def cancel_transfer(transfer_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_manager)):
    return svc.cancel_transfer(db, transfer_id)
