from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .config import settings
from .database import engine, Base
from .routers import (
    auth, master_data, dashboard, returns,
    receipts, deliveries, transfers, adjustments, stock_history
)

app = FastAPI(
    title=settings.PROJECT_NAME,
    description="Enterprise Inventory Management API with robust auth and transactional safety.",
    version=settings.VERSION,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router, prefix=settings.API_V1_STR)
app.include_router(dashboard.router, prefix=settings.API_V1_STR)
app.include_router(master_data.router, prefix=settings.API_V1_STR)
app.include_router(receipts.router, prefix=settings.API_V1_STR)
app.include_router(deliveries.router, prefix=settings.API_V1_STR)
app.include_router(transfers.router, prefix=settings.API_V1_STR)
app.include_router(adjustments.router, prefix=settings.API_V1_STR)
app.include_router(returns.router, prefix=settings.API_V1_STR)
app.include_router(stock_history.router, prefix=settings.API_V1_STR)

@app.get("/health", tags=["Health"])
def health():
    return {"status": "healthy", "database": "connected"}

@app.get("/ready", tags=["Health"])
def ready():
    return {"status": "ready"}
