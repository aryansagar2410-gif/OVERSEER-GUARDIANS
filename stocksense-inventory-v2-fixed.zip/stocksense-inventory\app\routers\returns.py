from typing import Optional
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import OperationStatus, User
from ..schemas import ReturnCreate, ReturnOut
from ..services import inventory_service as svc
from ..auth import get_staff, get_manager

router = APIRouter(prefix="/returns", tags=["🔙 Returns"])

@router.post("/", response_model=ReturnOut, status_code=201)
def create_return(data: ReturnCreate, db: Session = Depends(get_db), current_user: User = Depends(get_manager)):
    return svc.create_return(db, data, user_id=current_user.id)

@router.post("/{return_id}/validate", response_model=ReturnOut)
def validate_return(return_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_manager)):
    return svc.process_return(db, return_id, user_id=current_user.id)
