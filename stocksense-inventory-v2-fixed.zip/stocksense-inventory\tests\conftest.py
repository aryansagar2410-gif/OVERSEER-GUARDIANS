import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.database import Base, get_db
from app.main import app
from app.models import User, UserRole, Product, Location
from app.auth import get_current_user, get_manager, get_staff

SQLALCHEMY_DATABASE_URL = "sqlite://"

engine = create_engine(
    SQLALCHEMY_DATABASE_URL,
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

@pytest.fixture(autouse=True)
def setup_db():
    Base.metadata.create_all(bind=engine)
    db = TestingSessionLocal()
    admin = User(id=1, email="admin@test.com", username="admin", hashed_password="fake", role=UserRole.ADMIN)
    loc1 = Location(id=1, name="Loc1", code="L1")
    loc2 = Location(id=2, name="Loc2", code="L2")
    prod1 = Product(id=1, sku="P1", name="Product 1")
    prod2 = Product(id=2, sku="P2", name="Product 2")
    prod42 = Product(id=42, sku="P42", name="Product 42")
    prod5 = Product(id=5, sku="P5", name="Product 5")
    prod7 = Product(id=7, sku="P7", name="Product 7")
    prod99 = Product(id=99, sku="P99", name="Product 99")
    prod999 = Product(id=999, sku="P999", name="Product 999")
    
    db.add_all([admin, loc1, loc2, prod1, prod2, prod42, prod5, prod7, prod99, prod999])
    db.commit()
    db.close()
    
    yield
    Base.metadata.drop_all(bind=engine)

@pytest.fixture
def db():
    session = TestingSessionLocal()
    try:
        yield session
    finally:
        session.close()

def override_get_current_user():
    return User(id=1, email="admin@test.com", username="admin", role=UserRole.ADMIN, is_active=True)

@pytest.fixture
def client(db):
    app.dependency_overrides[get_db] = lambda: db
    app.dependency_overrides[get_current_user] = override_get_current_user
    app.dependency_overrides[get_manager] = override_get_current_user
    app.dependency_overrides[get_staff] = override_get_current_user
    
    with TestClient(app, base_url="http://testserver/api/v1") as c:
        yield c
    app.dependency_overrides.clear()

def seed_stock(client: TestClient, product_id: int, quantity: float, location_id: int = 1):
    resp = client.post("/receipts/", json={
        "vendor_name": "Seed Vendor",
        "items": [
            {"product_id": product_id, "location_id": location_id, "quantity_expected": quantity}
        ],
    })
    assert resp.status_code == 201
    receipt_id = resp.json()["id"]
    client.post(f"/receipts/{receipt_id}/confirm")
    client.post(f"/receipts/{receipt_id}/validate")
