from typing import Optional
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import OperationStatus, User
from ..schemas import ReceiptCreate, ReceiptUpdate, ReceiptOut
from ..services import inventory_service as svc
from ..auth import get_staff, get_manager

router = APIRouter(prefix="/receipts", tags=["📥 Receipts"])

@router.post("/", response_model=ReceiptOut, status_code=201)
def create_receipt(data: ReceiptCreate, db: Session = Depends(get_db), current_user: User = Depends(get_manager)):
    return svc.create_receipt(db, data, user_id=current_user.id)

@router.get("/", response_model=list[ReceiptOut])
def list_receipts(
    status: Optional[OperationStatus] = Query(None),
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_staff)
):
    return svc.list_receipts(db, status_filter=status, limit=limit, offset=offset)

@router.get("/{receipt_id}", response_model=ReceiptOut)
def get_receipt(receipt_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_staff)):
    return svc.get_receipt(db, receipt_id)

@router.patch("/{receipt_id}", response_model=ReceiptOut)
def update_receipt(receipt_id: int, data: ReceiptUpdate, db: Session = Depends(get_db), current_user: User = Depends(get_manager)):
    return svc.update_receipt(db, receipt_id, data)

@router.post("/{receipt_id}/confirm", response_model=ReceiptOut)
def confirm_receipt(receipt_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_manager)):
    return svc.confirm_receipt(db, receipt_id)

@router.post("/{receipt_id}/validate", response_model=ReceiptOut)
def validate_receipt(receipt_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_manager)):
    return svc.process_receipt(db, receipt_id, user_id=current_user.id)

@router.post("/{receipt_id}/cancel", response_model=ReceiptOut)
def cancel_receipt(receipt_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_manager)):
    return svc.cancel_receipt(db, receipt_id)
