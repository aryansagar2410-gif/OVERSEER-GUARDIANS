import os
import glob

routers_dir = r"C:\Users\BML\.gemini\antigravity\scratch\stocksense-inventory\app\routers"
files = ["receipts.py", "deliveries.py", "transfers.py", "adjustments.py"]

for f in files:
    path = os.path.join(routers_dir, f)
    with open(path, 'r', encoding='utf-8') as file:
        content = file.read()
    
    # Add imports
    if "from ..auth import get_staff, get_manager" not in content:
        content = content.replace("from ..database import get_db", "from ..database import get_db\nfrom ..auth import get_staff, get_manager\nfrom ..models import User")
    
    # Replace dependency in defs
    content = content.replace("db: Session = Depends(get_db)", "db: Session = Depends(get_db), current_user: User = Depends(get_staff())")
    
    # Fix the method calls to pass current_user.id
    import re
    content = re.sub(r'svc\.create_([a-z]+)\(db, data\)', r'svc.create_\1(db, data, user_id=current_user.id)', content)
    content = re.sub(r'svc\.process_([a-z]+)\(db, [a-z_]+\)', lambda m: m.group(0)[:-1] + r', user_id=current_user.id)', content)
    
    with open(path, 'w', encoding='utf-8') as file:
        file.write(content)
print("Routers patched successfully.")
