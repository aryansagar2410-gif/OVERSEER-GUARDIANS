"""StockSense — Inventory Operations Module."""
__version__ = "1.0.0"
