import sys
import logging
from sqlalchemy.orm import Session
from app.database import engine, Base, SessionLocal
from app.models import User, UserRole, Location, Supplier, Product
from app.auth import get_password_hash

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def seed():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    
    if db.query(User).first():
        logger.info("Database already seeded.")
        return
        
    logger.info("Seeding Initial Users...")
    admin = User(email="admin@stocksense.com", username="admin", hashed_password=get_password_hash("admin123"), role=UserRole.ADMIN)
    manager = User(email="manager@stocksense.com", username="manager", hashed_password=get_password_hash("manager123"), role=UserRole.MANAGER)
    staff = User(email="staff@stocksense.com", username="staff", hashed_password=get_password_hash("staff123"), role=UserRole.STAFF)
    db.add_all([admin, manager, staff])
    
    logger.info("Seeding Locations...")
    wh_main = Location(name="Main Warehouse", code="WH-01", type="WAREHOUSE")
    wh_sec = Location(name="Secondary Warehouse", code="WH-02", type="WAREHOUSE")
    store1 = Location(name="Downtown Store", code="ST-01", type="STORE")
    db.add_all([wh_main, wh_sec, store1])
    
    logger.info("Seeding Suppliers...")
    sup1 = Supplier(name="Tech Supplies Inc", contact_person="John Doe", email="john@techsupplies.com", phone="555-0101")
    sup2 = Supplier(name="Office Essentials", contact_person="Jane Smith", email="jane@officeessentials.com", phone="555-0202")
    db.add_all([sup1, sup2])
    db.commit() # Commit to get IDs
    
    logger.info("Seeding Products...")
    products = [
        Product(sku="LAP-001", barcode="100000001", name="Pro Laptop 15-inch", category="Electronics", brand="TechCorp", cost_price=800, selling_price=1200, supplier_id=sup1.id, reorder_level=10),
        Product(sku="MOU-001", barcode="100000002", name="Wireless Mouse", category="Electronics", brand="ClickMaster", cost_price=15, selling_price=45, supplier_id=sup1.id, reorder_level=50),
        Product(sku="DK-001", barcode="100000003", name="Standing Desk", category="Furniture", brand="ErgoFit", cost_price=200, selling_price=399, supplier_id=sup2.id, reorder_level=5),
        Product(sku="CH-001", barcode="100000004", name="Ergonomic Chair", category="Furniture", brand="ErgoFit", cost_price=150, selling_price=299, supplier_id=sup2.id, reorder_level=10),
    ]
    db.add_all(products)
    db.commit()
    
    logger.info("Seeding complete! Use admin/admin123 to login.")

if __name__ == "__main__":
    seed()
