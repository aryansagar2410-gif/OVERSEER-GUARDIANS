"""
Tests for Receipts — vendor stock comes in, stock ↑.

Key scenario from hackathon spec:
    100 → Receive 50 → 150
"""
from tests.conftest import seed_stock


class TestReceiptCRUD:
    """Create, read, update, list receipts."""

    def test_create_receipt_draft(self, client):
        resp = client.post("/api/v1/receipts/", json={
            "vendor_name": "Acme Supplies",
            "items": [
                {"product_id": 1, "location_id": 1, "quantity_expected": 50},
                {"product_id": 2, "location_id": 1, "quantity_expected": 30},
            ],
        })
        assert resp.status_code == 201
        data = resp.json()
        assert data["status"] == "DRAFT"
        assert data["reference"].startswith("REC-")
        assert data["vendor_name"] == "Acme Supplies"
        assert len(data["items"]) == 2

    def test_list_receipts(self, client):
        # create two receipts
        client.post("/api/v1/receipts/", json={
            "vendor_name": "V1",
            "items": [{"product_id": 1, "quantity_expected": 10}],
        })
        client.post("/api/v1/receipts/", json={
            "vendor_name": "V2",
            "items": [{"product_id": 2, "quantity_expected": 20}],
        })
        resp = client.get("/api/v1/receipts/")
        assert resp.status_code == 200
        assert len(resp.json()) == 2

    def test_list_receipts_filter_by_status(self, client):
        client.post("/api/v1/receipts/", json={
            "vendor_name": "V1",
            "items": [{"product_id": 1, "quantity_expected": 10}],
        })
        resp = client.get("/api/v1/receipts/?status=CONFIRMED")
        assert resp.status_code == 200
        assert len(resp.json()) == 0  # it's DRAFT, not CONFIRMED

    def test_update_draft_receipt(self, client):
        resp = client.post("/api/v1/receipts/", json={
            "vendor_name": "Old Name",
            "items": [{"product_id": 1, "quantity_expected": 10}],
        })
        rid = resp.json()["id"]
        resp2 = client.patch(f"/api/v1/receipts/{rid}", json={"vendor_name": "New Name"})
        assert resp2.status_code == 200
        assert resp2.json()["vendor_name"] == "New Name"


class TestReceiptLifecycle:
    """DRAFT → CONFIRMED → DONE lifecycle + stock validation."""

    def test_confirm_receipt(self, client):
        resp = client.post("/api/v1/receipts/", json={
            "vendor_name": "Vendor",
            "items": [{"product_id": 1, "quantity_expected": 50}],
        })
        rid = resp.json()["id"]
        resp2 = client.post(f"/api/v1/receipts/{rid}/confirm")
        assert resp2.status_code == 200
        assert resp2.json()["status"] == "CONFIRMED"

    def test_validate_receipt_increases_stock(self, client):
        """
        THE CORE TEST:
        Start with 100 stock, receive 50 → stock should be 150.
        """
        # Seed 100 units of product 1
        seed_stock(client, product_id=1, quantity=100)

        # Check stock = 100
        resp = client.get("/api/v1/stock/1")
        assert resp.json()["total_quantity"] == 100.0

        # Receive 50 more
        resp = client.post("/api/v1/receipts/", json={
            "vendor_name": "Second Batch",
            "items": [{"product_id": 1, "quantity_expected": 50}],
        })
        rid = resp.json()["id"]
        resp2 = client.post(f"/api/v1/receipts/{rid}/validate")
        assert resp2.status_code == 200
        assert resp2.json()["status"] == "DONE"

        # Stock should be 150
        resp3 = client.get("/api/v1/stock/1")
        assert resp3.json()["total_quantity"] == 150.0

    def test_cancel_receipt(self, client):
        resp = client.post("/api/v1/receipts/", json={
            "vendor_name": "Vendor",
            "items": [{"product_id": 1, "quantity_expected": 10}],
        })
        rid = resp.json()["id"]
        resp2 = client.post(f"/api/v1/receipts/{rid}/cancel")
        assert resp2.status_code == 200
        assert resp2.json()["status"] == "CANCELLED"

    def test_cannot_cancel_done_receipt(self, client):
        seed_stock(client, product_id=99, quantity=10)
        # The receipt is now DONE
        receipts = client.get("/api/v1/receipts/").json()
        rid = receipts[0]["id"]
        resp = client.post(f"/api/v1/receipts/{rid}/cancel")
        assert resp.status_code == 400

    def test_receipt_creates_ledger_entries(self, client):
        """Validate that processing a receipt writes to the central ledger."""
        seed_stock(client, product_id=42, quantity=75)
        resp = client.get("/api/v1/stock/history/all?product_id=42")
        assert resp.status_code == 200
        entries = resp.json()
        assert len(entries) >= 1
        assert entries[0]["movement_type"] == "RECEIPT"
        assert entries[0]["quantity"] == 75.0
