content = open('backend/__tests__/adjustments-semantics.test.ts').read()
content = content.replace('await prisma.();', 'await prisma.();')
open('backend/__tests__/adjustments-semantics.test.ts', 'w').write(content)
