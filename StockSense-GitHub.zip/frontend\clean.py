content = open('src/App.tsx').read()
content = content.replace("  INITIAL_MOVEMENTS,\n", "")
open('src/App.tsx', 'w').write(content)
