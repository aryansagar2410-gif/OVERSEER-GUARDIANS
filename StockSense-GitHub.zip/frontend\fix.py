content = open('src/App.tsx').read()
old_state = """  const [toast, setToast] = useState<ToastMessage | null>({
    id: 't-1',
    title: 'Receipt REC-2023-0891 validated',
    description: 'Stock updated (+120 units)',
    timestamp: '2m ago',
    type,
  });"""
new_state = """  const [toast, setToast] = useState<ToastMessage | null>({
    id: 't-1',
    title: 'Receipt REC-2023-0891 validated',
    description: 'Stock updated (+120 units)',
    timestamp: '2m ago',
    type: 'success',
  });"""
content = content.replace(old_state, new_state)
open('src/App.tsx', 'w').write(content)
