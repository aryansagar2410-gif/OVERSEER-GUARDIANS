import re
content = open('src/App.tsx').read()
content = re.sub(r'<DashboardView\n\s+warehouse=\{activeWarehouse\}\n\s+products=\{products\}\n\s+movements=\{movements\}', '<DashboardView\n                  warehouse={activeWarehouse}\n                  products={products}\n                  movements={movements}\n                  summary={dashboardSummary}', content)
open('src/App.tsx', 'w').write(content)
