content = open('src/App.tsx').read()
import re

content = content.replace("import { ReceiptsView } from './components/ReceiptsView';", "import { ReceiptsView } from './components/ReceiptsView';\nimport { DeliveriesView } from './components/DeliveriesView';\nimport { OutboundDelivery } from './types/inventory';")
content = content.replace("const [receipts, setReceipts] = useState<InboundReceipt[]>(INITIAL_RECEIPTS);", "const [receipts, setReceipts] = useState<InboundReceipt[]>(INITIAL_RECEIPTS);\n  const [deliveries, setDeliveries] = useState<OutboundDelivery[]>([]);")

handler = """  const handleValidateDelivery = async (delivery: OutboundDelivery) => {
    try {
      const { createDelivery } = await import('./api/deliveries');
      const product = products.find(p => p.sku === delivery.sku || p.name.includes(delivery.productName));
      if (!product) { showToast('Validation Failed', 'Product not found', 'warning'); return; }
      
      const fromLocationId = warehouses.find(w => w.name === delivery.sourceBay)?.id || warehouses[0]?.id;
      if (!fromLocationId) { showToast('Validation Failed', 'No valid warehouse location found', 'warning'); return; }
      
      await createDelivery({
        productId: product.id,
        fromLocationId,
        quantity: delivery.quantity,
        documentId: delivery.ref
      });

      setDeliveries(prev => prev.map(d => d.id === delivery.id ? { ...d, status: 'done', verifiedBy: 'System', verifiedTime: 'Just now' } : d));

      const { getProducts } = await import('./api/products');
      const pRes = await getProducts(1, 1000);
      setProducts(pRes.data);

      const { getMovements } = await import('./api/movements');
      const mRes = await getMovements(1, 100);
      setMovements(mRes.data);

      showToast(`Delivery ${delivery.ref} validated`, `Stock updated (-${delivery.quantity} units from ${delivery.sourceBay})`);
    } catch (err: any) {
      showToast('Validation Failed', err.message || 'Server error', 'warning');
    }
  };"""

content = content.replace("  const handleConfirmAdjust = async", handler + "\n\n  const handleConfirmAdjust = async")

old_render = """              {(currentTab === 'history' || currentTab === 'deliveries' || currentTab === 'transfers' || currentTab === 'adjustments') && (
                <MovementLedgerView"""
new_render = """              {currentTab === 'deliveries' && (
                <DeliveriesView
                  deliveries={deliveries}
                  onOpenCreateDelivery={() => {}} 
                  onOpenScanner={() => setScannerOpen(true)}
                  onValidateDelivery={handleValidateDelivery}
                />
              )}

              {(currentTab === 'history' || currentTab === 'transfers' || currentTab === 'adjustments') && (
                <MovementLedgerView"""
content = content.replace(old_render, new_render)

old_mobile_render = """              {(currentTab === 'history' || currentTab === 'deliveries' || currentTab === 'transfers' || currentTab === 'adjustments') && (
                  <MovementLedgerView"""
new_mobile_render = """              {currentTab === 'deliveries' && (
                  <DeliveriesView
                    deliveries={deliveries}
                    onOpenCreateDelivery={() => {}} 
                    onOpenScanner={() => setScannerOpen(true)}
                    onValidateDelivery={handleValidateDelivery}
                  />
                )}

                {(currentTab === 'history' || currentTab === 'transfers' || currentTab === 'adjustments') && (
                  <MovementLedgerView"""
content = content.replace(old_mobile_render, new_mobile_render)

open('src/App.tsx', 'w').write(content)
