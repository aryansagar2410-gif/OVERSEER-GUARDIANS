content = open('src/lib/rate-limit.ts').read()
old = """    for (const [key, value] of cache.entries()) {
      if (now > value.expiresAt) {
        cache.delete(key);
      }
    }"""
new = """    cache.forEach((value, key) => {
      if (now > value.expiresAt) {
        cache.delete(key);
      }
    });"""
content = content.replace(old, new)
open('src/lib/rate-limit.ts', 'w').write(content)
