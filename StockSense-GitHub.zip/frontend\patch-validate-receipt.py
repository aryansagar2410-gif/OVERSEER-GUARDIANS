content = open('src/App.tsx').read()
import re

old_func = r"""  const handleValidateReceipt = \(receipt: InboundReceipt\) => \{
    // 1\. Mark receipt as done
    setReceipts\(\(prev\) =>
      prev\.map\(\(r\) =>
        r\.id === receipt\.id
          \? \{
              \.\.\.r,
              status: 'done',
              verifiedBy: 'Elena Vance',
              verifiedTime: 'Just now',
              storedBin: r\.targetBay,
            \}
          : r
      \)
    \);

    // 2\. Increase product stock if product exists
    setProducts\(\(prev\) =>
      prev\.map\(\(p\) => \{
        if \(p\.sku === receipt\.sku \|\| p\.name\.includes\(receipt\.productName\)\) \{
          return \{
            \.\.\.p,
            onHand: p\.onHand \+ receipt\.quantity,
            status: 'healthy',
          \};
        \}
        return p;
      \}\)
    \);

    // 3\. Add to immutable movements ledger
    const newMovement: MovementRecord = \{
      id: `mov-\$\{Date\.now\(\)\}`,
      date: new Date\(\)\.toLocaleString\(\),
      type: 'RECEIPT',
      productName: receipt\.productName,
      sku: receipt\.sku,
      quantity: receipt\.quantity,
      source: receipt\.vendor,
      destination: receipt\.targetBay,
      status: 'completed',
      user: 'Elena Vance',
      reference: receipt\.ref,
    \};
    setMovements\(\(prev\) => \[newMovement, \.\.\.prev\]\);

    // 4\. Trigger Toast
    showToast\(
      `Receipt \$\{receipt\.ref\} validated`,
      `Stock updated \(\+\$\{receipt\.quantity\} units to \$\{receipt\.targetBay\}\)`
    \);
  \};"""

new_func = """  const handleValidateReceipt = async (receipt: InboundReceipt) => {
    try {
      const { createReceipt } = await import('./api/receipts');
      const product = products.find(p => p.sku === receipt.sku || p.name.includes(receipt.productName));
      if (!product) {
        showToast('Validation Failed', 'Product not found for this receipt', 'warning');
        return;
      }
      const toLocationId = warehouses.find(w => w.name === receipt.targetBay)?.id || warehouses[0]?.id;
      if (!toLocationId) {
        showToast('Validation Failed', 'No valid warehouse location found', 'warning');
        return;
      }
      
      await createReceipt({
        productId: product.id,
        toLocationId: toLocationId,
        quantity: receipt.quantity,
        documentId: receipt.ref
      });

      // Update UI state
      setReceipts((prev) =>
        prev.map((r) =>
          r.id === receipt.id
            ? { ...r, status: 'done', verifiedBy: 'System', verifiedTime: 'Just now', storedBin: r.targetBay }
            : r
        )
      );

      // Re-fetch products and movements to stay in sync
      const { getProducts } = await import('./api/products');
      const pRes = await getProducts(1, 1000);
      setProducts(pRes.data);

      const { getMovements } = await import('./api/movements');
      const mRes = await getMovements(1, 100);
      setMovements(mRes.data);

      showToast(
        `Receipt ${receipt.ref} validated`,
        `Stock updated (+${receipt.quantity} units to ${receipt.targetBay})`
      );
    } catch (err: any) {
      showToast('Validation Failed', err.message || 'Server error', 'warning');
    }
  };"""

content = re.sub(old_func, new_func, content)
open('src/App.tsx', 'w').write(content)
