content = open('backend/src/lib/auth.ts').read()
content = content.replace("jwt.sign(payload, JWT_SECRET, { expiresIn: '1d' })", "jwt.sign(payload, JWT_SECRET!, { expiresIn: '1d' })")
content = content.replace("jwt.verify(token, JWT_SECRET) as JwtPayload", "(jwt.verify(token, JWT_SECRET!) as unknown) as JwtPayload")
open('backend/src/lib/auth.ts', 'w').write(content)
