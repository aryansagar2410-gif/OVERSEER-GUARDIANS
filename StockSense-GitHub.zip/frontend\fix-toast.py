content = open('src/App.tsx').read()
content = content.replace("const showToast = (title: string, description: string, type: 'success' | 'error' | 'info' | 'warning' = 'success') => {", "const showToast = (title: string, description: string, type: 'success' | 'info' | 'warning' = 'success') => {")
content = content.replace("showToast('Unrecognized Scan', `Code ${code} did not match any Product or Receipt`, 'error');", "showToast('Unrecognized Scan', `Code ${code} did not match any Product or Receipt`, 'warning');")
open('src/App.tsx', 'w').write(content)
